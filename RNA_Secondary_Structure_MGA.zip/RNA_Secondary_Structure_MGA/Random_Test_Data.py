import random
Path = 'Merge_Data_RePeat/Resut_Bracket/RNA_Profile_Result_16RNA.txt'
Path_Test = open("Merge_Data_RePeat/Resut_Bracket/RNA_Profile_Result_16SRNA_Test.txt", 'w')
number = 0
List_Index = list(range(0, 118)) #取所有个体的下标
Test_Index = random.sample(List_Index, 100) #随机取100个个体
Test_Index = sorted(Test_Index) #对个体进行排序
Index = 0
Flag = False
for line in open(Path):
    if(Index < 100):
        if(line[0] == '>'):

            if(Test_Index[Index] == number):
                Flag = True
                Index += 1
            else:
                Flag = False
            number += 1
        if(Flag):
            Path_Test.write(line)
    else:
        break
#print(number)
#print(List_Index)
#print(Test_Index)
#print(len(Test_Index))