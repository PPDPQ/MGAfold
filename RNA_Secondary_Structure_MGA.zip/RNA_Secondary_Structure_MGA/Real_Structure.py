import os
def Structure_Readting_Real(File_Str):
    Path = 'Merge_Data_RePeat/NoRe_Test/RNaseP_Test/'
    Real_Structur = []
    Real_Sequence = ""
    Real_Restriction = ""
    File_Path = Path + File_Str
    for line in open(File_Path):
        line_list = line.split()
        if(line_list[1] == 'a' or line_list[1] == 'u' or line_list[1] == 'g' or line_list[1] == 'c' or line_list[1] == 'A' or line_list[1] == 'U' or line_list[1] == 'G' or line_list[1] == 'C'):
            Real_Structur.append(int(line_list[4])-1)
            Real_Sequence += line_list[1].upper()
            Real_Restriction += '_'
    return Real_Structur, Real_Sequence, Real_Restriction
def Structure_To_Stem(Real_Structure_To_Stem):
    Stem_Nest = []
    str_to_stem = 0
    while(str_to_stem < len(Real_Structure_To_Stem)):
        if(Real_Structure_To_Stem[str_to_stem] != -1 and Real_Structure_To_Stem[str_to_stem] > str_to_stem):
            Stem_Tem = []
            Stem_Tem.append(str_to_stem) #茎区起始
            Stem_Tem.append(Real_Structure_To_Stem[str_to_stem]) # 茎区终止
            length_stem = 1
            while(Real_Structure_To_Stem[str_to_stem] == Real_Structure_To_Stem[str_to_stem+1]+1):
                str_to_stem += 1
                length_stem += 1
            Stem_Tem.append(length_stem)
            Stem_Nest.append(Stem_Tem)
        str_to_stem += 1
    return Stem_Nest
def Predict_Structur_Transfor(Predicture_Structure_Bracket):
    Structure_Length = len(Predicture_Structure_Bracket)
    Predict_Structure_Tran = [-1 for i_structure in range(Structure_Length)]
    List_Big_Bracket = []   #存放{
    List_Mid_Bracket = []   #存放[
    List_Small_Bracket = [] #存放(
    for Bracket_Num in range(Structure_Length):
        if(Predicture_Structure_Bracket[Bracket_Num] == '('):
            List_Small_Bracket.append(Bracket_Num)
        if(Predicture_Structure_Bracket[Bracket_Num] == '['):
            List_Mid_Bracket.append(Bracket_Num)
        if(Predicture_Structure_Bracket[Bracket_Num] == '{'):
            List_Big_Bracket.append(Bracket_Num)
        if (Predicture_Structure_Bracket[Bracket_Num] == ')'):
            Predict_Structure_Tran[Bracket_Num] = List_Small_Bracket[len(List_Small_Bracket)-1]
            Predict_Structure_Tran[List_Small_Bracket[len(List_Small_Bracket)-1]] = Bracket_Num
            List_Small_Bracket.pop(len(List_Small_Bracket)-1)
        if(Predicture_Structure_Bracket[Bracket_Num] == ']'):
            Predict_Structure_Tran[Bracket_Num] = List_Mid_Bracket[len(List_Mid_Bracket) - 1]
            Predict_Structure_Tran[List_Mid_Bracket[len(List_Mid_Bracket) - 1]] = Bracket_Num
            List_Mid_Bracket.pop(len(List_Mid_Bracket) - 1)
        if(Predicture_Structure_Bracket[Bracket_Num] == '}'):
            Predict_Structure_Tran[Bracket_Num] = List_Big_Bracket[len(List_Big_Bracket) - 1]
            Predict_Structure_Tran[List_Big_Bracket[len(List_Big_Bracket) - 1]] = Bracket_Num
            List_Big_Bracket.pop(len(List_Big_Bracket) - 1)
    #print(Structure_Length)
    #print(Predict_Structure_Tran)
    #print(len(Predict_Structure_Tran))
    return Predict_Structure_Tran
def Performance(Predict_Structure, Real_Structure):
    TP = 0 #正确预测的配对碱基
    TN = 0 #正确预测的未配对碱基
    FP = 0 # 预测配对不正确的碱基
    FN = 0 # 真配对，预测为未配对碱基
    for Structure_Index in range(len(Predict_Structure)):
        if(Predict_Structure[Structure_Index] == Real_Structure[Structure_Index]):
            if(Real_Structure[Structure_Index] != -1):
                TP += 1
            else:
                TN += 1
        else:
            if(Predict_Structure[Structure_Index] != -1):
                FP += 1
            else:
                FN += 1
    return TP, TN, FP, FN


'''list_name = os.listdir("Merge_Data_RePeat/NoRe_Test/5S_Test/")
#print(os.getcwd())
#print(list_name)
All_PPV = 0
All_Sen = 0
All_F = 0
for i in range(len(list_name)):
    #print(i)
    print(list_name[i])
    os.chdir("/media/disk/lyuwang/RNA_Secondary_Structure_GA_2021.06.12")
    Real_Structur, Real_Sequence, Real_Restriction = Structure_Readting_Real(list_name[i])
    #print("%$#@!#$%#$#")
    #print(Real_Structur)
    #print(Real_Sequence)
    #print(Real_Restriction)
    #Stem_Nest = Structure_To_Stem(Real_Structur)
    #print(Stem_Nest)
    #break
    #print(Real_Structur)
    #print(Real_Sequence)
    #print(Real_Restriction)
    New_Real_Restriction = ''
    for iii in range(len(Real_Structur)):
        if(Real_Structur[iii] != -1):
            if(Real_Structur[iii] > iii):
                New_Real_Restriction += '('
            else:
                New_Real_Restriction += ')'
        else:
            New_Real_Restriction += '.'

    #print(len(Real_Sequence))
    #print(Real_Structur)
    print(New_Real_Restriction)
'''
'''
    os.chdir('/media/disk/lyuwang/RNA_Secondary_Structure_Program/HFold-master')
    Command_HFold = './HFold --s "' + Real_Sequence
    Command_HFold = Command_HFold + '"'
    Command_HFold = Command_HFold + ' --r "'
    Command_HFold = Command_HFold + Real_Restriction
    Command_HFold = Command_HFold + '"'
    #print(Command_HFold)
    #print(Command_HFold)
    #print(len(Real_Sequence))
    #if(len(Real_Sequence) < 1000):
    text = os.popen(Command_HFold).read()
    list_str = text.split()
    Predict_Structure_Tran = Predict_Structur_Transfor(list_str[3])
    #print(Predict_Structure_Tran)
    TP, TN, FP, FN = Performance(Predict_Structure_Tran, Real_Structur)
    if(TP + FP == 0):
        PPV = 0
    else:
        PPV = TP / (TP + FP)
    if(TP + FN == 0):
        SEN = 0
    else:
        SEN = TP / (TP + FN)
    if(SEN + PPV == 0):
        F_score = 0
    else:
        F_score = (2 * SEN * PPV) / (SEN + PPV)
    All_PPV += PPV
    All_Sen += SEN
    All_F += F_score
    print(PPV)
    print(SEN)
    print(F_score)
    break
'''
#Real_Structure_Stem = Stem_Structure(Real_Structure)
#print(Real_Structure_Stem)
#Stem_To_Structure(Real_Structur, Real_Structure)
'''TP, TN, FP, FN = Performance(Real_Structur, Real_Structur)
print(TP)
print(TN)
print(FP)
print(FN)

PPV = TP/(TP + FP)
SEN = TP/(TP + FN)
F_score = (2*SEN*PPV)/(SEN + PPV)

print(PPV)
print(SEN)
print(F_score)'''

#print("#######################")
#print(All_PPV/len(list_name))
#print(All_Sen/len(list_name))
#print(All_F/len(list_name))

#P =  'Profile_Family_CT_Data/5S_RNA_NoRe/5s_Methanococcus-vannielii-2.ct'

#for line in open(P):
#    print(line)