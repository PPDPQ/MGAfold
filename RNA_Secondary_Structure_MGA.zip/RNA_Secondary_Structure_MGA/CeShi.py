Dict = dict()



def AdjustDown(nums, k):
    length = len(nums)
    Number = nums[k]
    Index = 2*k + 1
    while(Index < length):
        if(Index < length-1 and nums[Index] > nums[Index+1]):
            Index += 1
        if(Number < nums[Index]):
            break
        else:
            nums[k] = nums[Index]
            k = Index
        Index = Index*2 + 1
    nums[k] = Number

def Build(nums):
    length = len(nums)
    Index = int(length/2)
    while(Index >= 0):
        AdjustDown(nums, Index)
        Index -= 1
    return nums


def Sort(nums):
    List_Result = []
    while(len(nums)!= 0):
        nums = Build(nums)
        List_Result.append(nums[0])
        del nums[0]
    return List_Result


nums = [53, 17, 78, 9, 45, 65, 87, 32]
List_Result = Sort(nums)
print(List_Result)