import math
#未考虑dangle链
#发卡环、凸环、内环、多分支环能量计算方法
#茎区能量计算方法
def Energy_Stem(Stem, Sequence): #计算茎区能量
    Energy = 4.09
    k = 0
    while(k < Stem[2]-1):
        Curr_Start = Stem[0] + k
        Curr_End = Stem[1] - k
        Next_Start = Curr_Start + 1
        Next_End = Curr_End -1
        if(Sequence[Curr_Start] == 'A' and Sequence[Curr_End] == 'U'):
            if(Sequence[Next_Start] == 'A' and Sequence[Next_End] == 'U'):
                Energy += -0.93
            if(Sequence[Next_Start] == 'U' and Sequence[Next_End] == 'A'):
                Energy += -1.10
            if (Sequence[Next_Start] == 'G' and Sequence[Next_End] == 'C'):
                Energy += -2.08
            if (Sequence[Next_Start] == 'C' and Sequence[Next_End] == 'G'):
                Energy += -2.24
        if (Sequence[Curr_Start] == 'U' and Sequence[Curr_End] == 'A'):
            if (Sequence[Next_Start] == 'A' and Sequence[Next_End] == 'U'):
                Energy += -1.33
            if (Sequence[Next_Start] == 'U' and Sequence[Next_End] == 'A'):
                Energy += -0.93
            if (Sequence[Next_Start] == 'G' and Sequence[Next_End] == 'C'):
                Energy += -2.11
            if (Sequence[Next_Start] == 'C' and Sequence[Next_End] == 'G'):
                Energy += -2.35
        if (Sequence[Curr_Start] == 'G' and Sequence[Curr_End] == 'C'):
            if (Sequence[Next_Start] == 'A' and Sequence[Next_End] == 'U'):
                Energy += -2.35
            if (Sequence[Next_Start] == 'U' and Sequence[Next_End] == 'A'):
                Energy += -2.24
            if (Sequence[Next_Start] == 'G' and Sequence[Next_End] == 'C'):
                Energy += -3.26
            if (Sequence[Next_Start] == 'C' and Sequence[Next_End] == 'G'):
                Energy += -3.42
        if (Sequence[Curr_Start] == 'C' and Sequence[Curr_End] == 'G'):
            if (Sequence[Next_Start] == 'A' and Sequence[Next_End] == 'U'):
                Energy += -2.11
            if (Sequence[Next_Start] == 'U' and Sequence[Next_End] == 'A'):
                Energy += -2.08
            if (Sequence[Next_Start] == 'G' and Sequence[Next_End] == 'C'):
                Energy += -2.36
            if (Sequence[Next_Start] == 'C' and Sequence[Next_End] == 'G'):
                Energy += -3.26
        k += 1
    if(Sequence[Stem[0]] == 'A' and Sequence[Stem[1]] == 'U'): #终端A-U封口惩罚
        Energy += 0.45
    if (Sequence[Stem[0]] == 'U' and Sequence[Stem[1]] == 'A'):
        Energy += 0.45
    if(Sequence[Stem[0] + Stem[2]-1] == 'A' and Sequence[Stem[1]-Stem[2] + 1] == 'U'):
        Energy += 0.45
    if (Sequence[Stem[0] + Stem[2]-1] == 'U' and Sequence[Stem[1]-Stem[2] + 1] == 'A'):
        Energy += 0.45
    return Energy

def Hair_Energy(Sequence, Start, End): #已经验证
    Length_Hair = End - Start + 1
    Energy_Pair = 0
    if(Length_Hair == 3): #发卡环初始值
        Energy_Pair += 5.4
    elif(Length_Hair == 4):
        Energy_Pair += 5.6
    elif(Length_Hair == 5):
        Energy_Pair += 5.7
    elif(Length_Hair == 6):
        Energy_Pair += 5.4
    elif(Length_Hair == 7):
        Energy_Pair += 6.0
    elif(Length_Hair == 8):
        Energy_Pair += 5.5
    elif(Length_Hair == 9):
        Energy_Pair += 6.4
    elif(Length_Hair == 10):
        Energy_Pair += 6.5
    elif (Length_Hair == 11):
        Energy_Pair += 6.6
    elif (Length_Hair == 12):
        Energy_Pair += 6.7
    elif(Length_Hair == 13):
        Energy_Pair += 6.8
    elif(Length_Hair == 14):
        Energy_Pair += 6.9
    elif(Length_Hair == 15):
        Energy_Pair += 6.9
    elif(Length_Hair == 16):
        Energy_Pair += 7.0
    elif(Length_Hair == 17):
        Energy_Pair += 7.1
    elif(Length_Hair == 18):
        Energy_Pair += 7.1
    elif(Length_Hair == 19):
        Energy_Pair += 7.2
    elif(Length_Hair == 20):
        Energy_Pair += 7.2
    elif(Length_Hair == 21):
        Energy_Pair += 7.3
    elif(Length_Hair == 22):
        Energy_Pair += 7.3
    elif(Length_Hair == 23):
        Energy_Pair += 7.4
    elif(Length_Hair == 24):
        Energy_Pair += 7.4
    elif(Length_Hair == 25):
        Energy_Pair += 7.5
    elif(Length_Hair == 26):
        Energy_Pair += 7.5
    elif(Length_Hair == 27):
        Energy_Pair += 7.5
    elif(Length_Hair == 28):
        Energy_Pair += 7.6
    elif(Length_Hair == 29):
        Energy_Pair += 7.6
    elif(Length_Hair == 30):
        Energy_Pair += 7.7
    else:
        Eng_Tem = 6.4 + 1.75*0.616*math.log(Length_Hair/9, math.e) #R*T =0.616
        Energy_Pair += Eng_Tem

    if (Sequence[Start - 1] == 'A' and Sequence[End + 1] == 'U'): # 发卡环错配

        if (Sequence[Start] == 'A' and Sequence[End] == 'A'):
            Energy_Pair += -0.8
        if (Sequence[Start] == 'A' and Sequence[End] == 'C'):
            Energy_Pair += -1.0
        if (Sequence[Start] == 'A' and Sequence[End] == 'G'):
            Energy_Pair += -0.8
        if (Sequence[Start] == 'A' and Sequence[End] == 'U'):
            Energy_Pair += -1.0

        if (Sequence[Start] == 'C' and Sequence[End] == 'A'):
            Energy_Pair += -0.6
        if (Sequence[Start] == 'C' and Sequence[End] == 'C'):
            Energy_Pair += -0.7
        if (Sequence[Start] == 'C' and Sequence[End] == 'G'):
            Energy_Pair += -0.6
        if (Sequence[Start] == 'C' and Sequence[End] == 'U'):
            Energy_Pair += -0.7

        if (Sequence[Start] == 'G' and Sequence[End] == 'A'):
            Energy_Pair += -0.8
        if (Sequence[Start] == 'G' and Sequence[End] == 'C'):
            Energy_Pair += -1.0
        if (Sequence[Start] == 'G' and Sequence[End] == 'G'):
            Energy_Pair += -0.8
        if (Sequence[Start] == 'G' and Sequence[End] == 'U'):
            Energy_Pair += -1.0

        if (Sequence[Start] == 'U' and Sequence[End] == 'A'):
            Energy_Pair += -0.6
        if (Sequence[Start] == 'U' and Sequence[End] == 'C'):
            Energy_Pair += -0.8
        if (Sequence[Start] == 'U' and Sequence[End] == 'G'):
            Energy_Pair += -0.6
        if (Sequence[Start] == 'U' and Sequence[End] == 'U'):
            Energy_Pair += -0.8

    if(Sequence[Start-1] == 'U' and Sequence[End+1] == 'A'):

        if(Sequence[Start] == 'A' and Sequence[End] == 'A'):
            Energy_Pair += -1.0
        if (Sequence[Start] == 'A' and Sequence[End] == 'C'):
            Energy_Pair += -0.8
        if (Sequence[Start] == 'A' and Sequence[End] == 'G'):
            Energy_Pair += -1.1
        if(Sequence[Start] == 'A' and Sequence[End] == 'U'):
            Energy_Pair += -0.8

        if(Sequence[Start] == 'C' and Sequence[End] == 'A'):
            Energy_Pair += -0.7
        if (Sequence[Start] == 'C' and Sequence[End] == 'C'):
            Energy_Pair += -0.6
        if (Sequence[Start] == 'C' and Sequence[End] == 'G'):
            Energy_Pair += -0.7
        if(Sequence[Start] == 'C' and Sequence[End] == 'U'):
            Energy_Pair += -0.5

        if(Sequence[Start] == 'G' and Sequence[End] == 'A'):
            Energy_Pair += -1.1
        if (Sequence[Start] == 'G' and Sequence[End] == 'C'):
            Energy_Pair += -0.8
        if (Sequence[Start] == 'G' and Sequence[End] == 'G'):
            Energy_Pair += -1.2
        if(Sequence[Start] == 'G' and Sequence[End] == 'U'):
            Energy_Pair += -0.8

        if(Sequence[Start] == 'U' and Sequence[End] == 'A'):
            Energy_Pair += -0.7
        if (Sequence[Start] == 'U' and Sequence[End] == 'C'):
            Energy_Pair += -0.6
        if (Sequence[Start] == 'U' and Sequence[End] == 'G'):
            Energy_Pair += -0.7
        if(Sequence[Start] == 'U' and Sequence[End] == 'U'):
            Energy_Pair += -0.5

    if (Sequence[Start - 1] == 'G' and Sequence[End + 1] == 'C'):

        if (Sequence[Start] == 'A' and Sequence[End] == 'A'):
            Energy_Pair += -1.1
        if (Sequence[Start] == 'A' and Sequence[End] == 'C'):
            Energy_Pair += -1.5
        if (Sequence[Start] == 'A' and Sequence[End] == 'G'):
            Energy_Pair += -1.3
        if (Sequence[Start] == 'A' and Sequence[End] == 'U'):
            Energy_Pair += -1.5

        if (Sequence[Start] == 'C' and Sequence[End] == 'A'):
            Energy_Pair += -1.1
        if (Sequence[Start] == 'C' and Sequence[End] == 'C'):
            Energy_Pair += -0.7
        if (Sequence[Start] == 'C' and Sequence[End] == 'G'):
            Energy_Pair += -1.1
        if (Sequence[Start] == 'C' and Sequence[End] == 'U'):
            Energy_Pair += -0.5

        if (Sequence[Start] == 'G' and Sequence[End] == 'A'):
            Energy_Pair += -1.6
        if (Sequence[Start] == 'G' and Sequence[End] == 'C'):
            Energy_Pair += -1.5
        if (Sequence[Start] == 'G' and Sequence[End] == 'G'):
            Energy_Pair += -1.4
        if (Sequence[Start] == 'G' and Sequence[End] == 'U'):
            Energy_Pair += -1.5

        if (Sequence[Start] == 'U' and Sequence[End] == 'A'):
            Energy_Pair += -1.1
        if (Sequence[Start] == 'U' and Sequence[End] == 'C'):
            Energy_Pair += -1.0
        if (Sequence[Start] == 'U' and Sequence[End] == 'G'):
            Energy_Pair += -1.1
        if (Sequence[Start] == 'U' and Sequence[End] == 'U'):
            Energy_Pair += -0.7

    if (Sequence[Start - 1] == 'C' and Sequence[End + 1] == 'G'):

        if (Sequence[Start] == 'A' and Sequence[End] == 'A'):
            Energy_Pair += -1.5
        if (Sequence[Start] == 'A' and Sequence[End] == 'C'):
            Energy_Pair += -1.5
        if (Sequence[Start] == 'A' and Sequence[End] == 'G'):
            Energy_Pair += -1.4
        if (Sequence[Start] == 'A' and Sequence[End] == 'U'):
            Energy_Pair += -1.5

        if (Sequence[Start] == 'C' and Sequence[End] == 'A'):
            Energy_Pair += -1.0
        if (Sequence[Start] == 'C' and Sequence[End] == 'C'):
            Energy_Pair += -1.1
        if (Sequence[Start] == 'C' and Sequence[End] == 'G'):
            Energy_Pair += -1.0
        if (Sequence[Start] == 'C' and Sequence[End] == 'U'):
            Energy_Pair += -0.8

        if (Sequence[Start] == 'G' and Sequence[End] == 'A'):
            Energy_Pair += -1.4
        if (Sequence[Start] == 'G' and Sequence[End] == 'C'):
            Energy_Pair += -1.5
        if (Sequence[Start] == 'G' and Sequence[End] == 'G'):
            Energy_Pair += -1.6
        if (Sequence[Start] == 'G' and Sequence[End] == 'U'):
            Energy_Pair += -1.5

        if (Sequence[Start] == 'U' and Sequence[End] == 'A'):
            Energy_Pair += -1.0
        if (Sequence[Start] == 'U' and Sequence[End] == 'C'):
            Energy_Pair += -1.4
        if (Sequence[Start] == 'U' and Sequence[End] == 'G'):
            Energy_Pair += -1.0
        if (Sequence[Start] == 'U' and Sequence[End] == 'U'):
            Energy_Pair += -1.2

    if (Length_Hair >= 4):  # 错配
        if (Sequence[Start] == 'U' and Sequence[End] == 'U'):
            Energy_Pair += -0.9
        if (Sequence[Start] == 'G' and Sequence[End] == 'A'):
            Energy_Pair += -0.9
        if (Sequence[Start] == 'G' and Sequence[End] == 'G'):
            Energy_Pair += -0.8

    Energy_Pair -= 4.09 # 减去茎区初始值

    flag = 0
    k = Start
    while(k <= End): # 判断是否全为C
        if(Sequence[k] != 'C'):
            flag = 1
            break
        k += 1
    if(flag == 0):
        if(Length_Hair == 3):
            Energy_Pair += 0
        else:
            Eng_Tem = 0.3*Length_Hair + 1.6
            Energy_Pair += Eng_Tem

    return Energy_Pair

def Bulge_Energy(Sequence, Start, End, Structure_Nest): #计算发卡环能量
    # 已经验证
    Energy_Bul = 0
    Length_Bul = End - Start + 1 # 凸环长度
    if(Length_Bul == 1): #计算初始值
        Energy_Bul += 3.8
    elif(Length_Bul == 2):
        Energy_Bul += 2.8
    elif(Length_Bul == 3):
        Energy_Bul += 3.2
    elif (Length_Bul == 4):
        Energy_Bul += 3.6
    elif (Length_Bul == 5):
        Energy_Bul += 4.0
    elif (Length_Bul == 6):
        Energy_Bul += 4.4
    elif (Length_Bul == 7):
        Energy_Bul += 4.6
    elif (Length_Bul == 8):
        Energy_Bul += 4.7
    elif (Length_Bul == 9):
        Energy_Bul += 4.8
    elif (Length_Bul == 10):
        Energy_Bul += 4.9
    elif (Length_Bul == 11):
        Energy_Bul += 5.0
    elif (Length_Bul == 12):
        Energy_Bul += 5.1
    elif (Length_Bul == 13):
        Energy_Bul += 5.2
    elif (Length_Bul == 14):
        Energy_Bul += 5.3
    elif (Length_Bul == 15):
        Energy_Bul += 5.4
    elif (Length_Bul == 16):
        Energy_Bul += 5.4
    elif (Length_Bul == 17):
        Energy_Bul += 5.5
    elif (Length_Bul == 18):
        Energy_Bul += 5.5
    elif (Length_Bul == 19):
        Energy_Bul += 5.6
    elif (Length_Bul == 20):
        Energy_Bul += 5.7
    elif (Length_Bul == 21):
        Energy_Bul += 5.7
    elif (Length_Bul == 22):
        Energy_Bul += 5.8
    elif (Length_Bul == 23):
        Energy_Bul += 5.8
    elif (Length_Bul == 24):
        Energy_Bul += 5.8
    elif (Length_Bul == 25):
        Energy_Bul += 5.9
    elif (Length_Bul == 26):
        Energy_Bul += 5.9
    elif (Length_Bul == 27):
        Energy_Bul += 6.0
    elif (Length_Bul == 28):
        Energy_Bul += 6.0
    elif (Length_Bul == 29):
        Energy_Bul += 6.0
    elif (Length_Bul == 30):
        Energy_Bul += 6.1
    else:
        Eng_Tem = 4.4 + 1.75*0.616*math.log(Length_Bul/6, math.e)
        Energy_Bul += Eng_Tem

    if(Length_Bul == 1):
        Curr_Start = Start -1
        Curr_End = Structure_Nest[Curr_Start]
        Next_Start = Start + 1
        Next_End = Structure_Nest[Next_Start]
        if(Sequence[Start] == 'C' and(Sequence[Curr_Start] == 'C' or Sequence[Next_Start] == 'C' or Sequence[Curr_End] == 'C' or Sequence[Next_End] == 'C')): # 环是一个C，临近配对至少一个C
            Energy_Bul += -0.9
        if(Sequence[Curr_Start] == 'A'):#取消茎区末端A-U惩罚
            Energy_Bul += -0.45
        if(Sequence[Next_Start] == 'A'):#取消茎区末端A-U惩罚
            Energy_Bul += -0.45
        states = 1 # 判断凸环有多少种状态
        Index = Curr_Start
        while(Index > 0 and Structure_Nest[Index] != -1):
            if(Sequence[Index] == Sequence[Start]):
                states += 1
            Index -= 1
        Index = Next_Start
        while(Index > len(Sequence) and Structure_Nest[Index] != -1):
            if(Sequence[Index] == Sequence[Start]):
                states += 1
            Index += 1
        Energy_Bul -= 0.616*math.log(states, math.e) # 减去状态的能量值
        if(Curr_Start > Curr_End): #当凸环在3‘端时,交换位置
            Tem_Num = Curr_Start
            Curr_Start = Next_End
            Next_End = Tem_Num

            Tem_Num = Next_Start
            Next_Start = Curr_End
            Curr_End = Tem_Num
        if (Sequence[Curr_Start] == 'A' and Sequence[Curr_End] == 'U'):
            if (Sequence[Next_Start] == 'A' and Sequence[Next_End] == 'U'):
                Energy_Bul += -0.93
            if (Sequence[Next_Start] == 'U' and Sequence[Next_End] == 'A'):
                Energy_Bul += -1.10
            if (Sequence[Next_Start] == 'G' and Sequence[Next_End] == 'C'):
                Energy_Bul += -2.08
            if (Sequence[Next_Start] == 'C' and Sequence[Next_End] == 'G'):
                Energy_Bul += -2.24

        if (Sequence[Curr_Start] == 'U' and Sequence[Curr_End] == 'A'):
            if (Sequence[Next_Start] == 'A' and Sequence[Next_End] == 'U'):
                Energy_Bul += -1.33
            if (Sequence[Next_Start] == 'U' and Sequence[Next_End] == 'A'):
                Energy_Bul += -0.93
            if (Sequence[Next_Start] == 'G' and Sequence[Next_End] == 'C'):
                Energy_Bul += -2.11
            if (Sequence[Next_Start] == 'C' and Sequence[Next_End] == 'G'):
                Energy_Bul += -2.35

        if (Sequence[Curr_Start] == 'G' and Sequence[Curr_End] == 'C'):
            if (Sequence[Next_Start] == 'A' and Sequence[Next_End] == 'U'):
                Energy_Bul += -2.35
            if (Sequence[Next_Start] == 'U' and Sequence[Next_End] == 'A'):
                Energy_Bul += -2.24
            if (Sequence[Next_Start] == 'G' and Sequence[Next_End] == 'C'):
                Energy_Bul += -3.26
            if (Sequence[Next_Start] == 'C' and Sequence[Next_End] == 'G'):
                Energy_Bul += -3.42

        if (Sequence[Curr_Start] == 'C' and Sequence[Curr_End] == 'G'):
            if (Sequence[Next_Start] == 'A' and Sequence[Next_End] == 'U'):
                Energy_Bul += -2.11
            if (Sequence[Next_Start] == 'U' and Sequence[Next_End] == 'A'):
                Energy_Bul += -2.08
            if (Sequence[Next_Start] == 'G' and Sequence[Next_End] == 'C'):
                Energy_Bul += -2.36
            if (Sequence[Next_Start] == 'C' and Sequence[Next_End] == 'G'):
                Energy_Bul += -3.26

    Energy_Bul -= 4.09 #减去一个茎区的初始值
    return Energy_Bul

def Int_Energy(Sequence, Start, End, End_Front,Start_Rear):
    Energy_Int = 0
    Length_Front = End_Front - Start + 1
    Length_Rear = End - Start_Rear + 1
    if(Length_Front == 2 and Length_Rear == 2):
        if (Sequence[Start - 1] == 'A' or Sequence[End + 1] == 'U'): # 5’端配对碱基
            if (Sequence[End_Front + 1] == 'A' or Sequence[Start_Rear - 1] == 'U'): #3’端配对碱基
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8
            if (Sequence[End_Front + 1] == 'U' or Sequence[Start_Rear - 1] == 'A'):  # 3’端配对碱基
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.4
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.6
            if (Sequence[End_Front + 1] == 'G' or Sequence[Start_Rear - 1] == 'C'):  # 3’端配对碱基
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.6
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.1
            if (Sequence[End_Front + 1] == 'C' or Sequence[Start_Rear - 1] == 'G'):  # 3’端配对碱基
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.6
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.1
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0
        if (Sequence[Start - 1] == 'U' or Sequence[End + 1] == 'A'): # 5’端配对碱基
            if (Sequence[End_Front + 1] == 'A' or Sequence[Start_Rear - 1] == 'U'): #3’端配对碱基
                if(Sequence[Start] == 'A' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
            if (Sequence[End_Front + 1] == 'U' or Sequence[Start_Rear - 1] == 'A'):  # 3’端配对碱基
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.6
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8
            if (Sequence[End_Front + 1] == 'G' or Sequence[Start_Rear - 1] == 'C'):  # 3’端配对碱基
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.1
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
            if (Sequence[End_Front + 1] == 'C' or Sequence[Start_Rear - 1] == 'G'):  # 3’端配对碱基
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.1
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
        if (Sequence[Start - 1] == 'G' or Sequence[End + 1] == 'C'): # 5’端配对碱基
            if (Sequence[End_Front + 1] == 'A' or Sequence[Start_Rear - 1] == 'U'): #3’端配对碱基
                if(Sequence[Start] == 'A' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.3

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.1
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.7
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
            if (Sequence[End_Front + 1] == 'U' or Sequence[Start_Rear - 1] == 'A'):  # 3’端配对碱基
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.3
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -1.0
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0
            if (Sequence[End_Front + 1] == 'G' or Sequence[Start_Rear - 1] == 'C'):  # 3’端配对碱基
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.5
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.6
            if (Sequence[End_Front + 1] == 'C' or Sequence[Start_Rear - 1] == 'G'):  # 3’端配对碱基
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.9
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -2.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.8

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.8

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -1.5
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.1
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.5
        if (Sequence[Start - 1] == 'C' or Sequence[End + 1] == 'G'): # 5’端配对碱基
            if (Sequence[End_Front + 1] == 'A' or Sequence[Start_Rear - 1] == 'U'): #3’端配对碱基
                if(Sequence[Start] == 'A' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.6

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
            if (Sequence[End_Front + 1] == 'U' or Sequence[Start_Rear - 1] == 'A'):  # 3’端配对碱基
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.3
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.3
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.3
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.3
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.8

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.1
            if (Sequence[End_Front + 1] == 'G' or Sequence[Start_Rear - 1] == 'C'):  # 3’端配对碱基
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.3

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.5
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.6
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.5
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.5
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.8
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.5
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.4
            if (Sequence[End_Front + 1] == 'C' or Sequence[Start_Rear - 1] == 'G'):  # 3’端配对碱基
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -1.6
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'A' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.2
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.3

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.1
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
                if (Sequence[Start] == 'C' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.1

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.1

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.9
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.9
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.4

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.4

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4
                if (Sequence[Start] == 'G' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.7
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.2

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.4
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.7
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += -0.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += -0.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.0

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3
                if (Sequence[Start] == 'U' and Sequence[End_Front] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.5
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3

                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3

                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.4
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 0.3

                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 0.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += -0.6
    elif(Length_Front == 1 and Length_Rear == 2):
        if (Sequence[Start - 1] == 'A' or Sequence[End + 1] == 'U'):
            if (Sequence[End_Front + 1] == 'A' or Sequence[Start_Rear - 1] == 'U'):
                if (Sequence[Start] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[Start] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[Start] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[Start] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
            if (Sequence[End_Front + 1] == 'U' or Sequence[Start_Rear - 1] == 'A'):
                if (Sequence[Start] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[Start] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[Start] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[Start] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
            if (Sequence[End_Front + 1] == 'G' or Sequence[Start_Rear - 1] == 'C'):
                if (Sequence[Start] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
            if (Sequence[End_Front + 1] == 'C' or Sequence[Start_Rear - 1] == 'G'):
                if (Sequence[Start] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
        if (Sequence[Start - 1] == 'U' or Sequence[End + 1] == 'A'):
            if (Sequence[End_Front + 1] == 'A' or Sequence[Start_Rear - 1] == 'U'):
                if (Sequence[Start] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[Start] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[Start] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[Start] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
            if (Sequence[End_Front + 1] == 'U' or Sequence[Start_Rear - 1] == 'A'):
                if (Sequence[Start] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[Start] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[Start] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.6

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[Start] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
            if (Sequence[End_Front + 1] == 'G' or Sequence[Start_Rear - 1] == 'C'):
                if (Sequence[Start] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
            if (Sequence[End_Front + 1] == 'C' or Sequence[Start_Rear - 1] == 'G'):
                if (Sequence[Start] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
        if (Sequence[Start - 1] == 'G' or Sequence[End + 1] == 'C'):
            if (Sequence[End_Front + 1] == 'A' or Sequence[Start_Rear - 1] == 'U'):
                if (Sequence[Start] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
            if (Sequence[End_Front + 1] == 'U' or Sequence[Start_Rear - 1] == 'A'):
                if (Sequence[Start] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
            if (Sequence[End_Front + 1] == 'G' or Sequence[Start_Rear - 1] == 'C'):
                if (Sequence[Start] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[Start] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[Start] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[Start] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
            if (Sequence[End_Front + 1] == 'C' or Sequence[Start_Rear - 1] == 'G'):
                if (Sequence[Start] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[Start] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[Start] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[Start] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
        if (Sequence[Start - 1] == 'C' or Sequence[End + 1] == 'G'):
            if (Sequence[End_Front + 1] == 'A' or Sequence[Start_Rear - 1] == 'U'):
                if (Sequence[Start] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
            if (Sequence[End_Front + 1] == 'U' or Sequence[Start_Rear - 1] == 'A'):
                if (Sequence[Start] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[Start] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.2

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.2
            if (Sequence[End_Front + 1] == 'G' or Sequence[Start_Rear - 1] == 'C'):
                if (Sequence[Start] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[Start] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[Start] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[Start] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
            if (Sequence[End_Front + 1] == 'C' or Sequence[Start_Rear - 1] == 'G'):
                if (Sequence[Start] == 'A'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[Start] == 'C'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[Start] == 'G'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 0.8
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.1

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[Start] == 'U'):
                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'A'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'C'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'G'):
                        Energy_Int += 1.5

                    if (Sequence[End] == 'A' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'C' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.7
                    if (Sequence[End] == 'G' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End] == 'U' and Sequence[Start_Rear] == 'U'):
                        Energy_Int += 1.4
    elif(Length_Front == 2 and Length_Rear == 1):
        if (Sequence[End_Front + 1] == 'U' or Sequence[Start_Rear - 1] == 'A'):
            if (Sequence[Start - 1] == 'U' or Sequence[End + 1] == 'A'):
                if (Sequence[End] == 'A'):
                    if (Sequence[Start] == 'A' and Sequence[End_Front] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[Start] == 'A' and Sequence[End_Front] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[Start] == 'A' and Sequence[End_Front] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[Start] == 'A' and Sequence[End_Front] == 'U'):
                        Energy_Int += 3.7

                    if (Sequence[Start] == 'C' and Sequence[End_Front] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[Start] == 'C' and Sequence[End_Front] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[Start] == 'C' and Sequence[End_Front] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[Start] == 'C' and Sequence[End_Front] == 'U'):
                        Energy_Int += 3.7

                    if (Sequence[Start] == 'G' and Sequence[End_Front] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[Start] == 'G' and Sequence[End_Front] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[Start] == 'G' and Sequence[End_Front] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[Start] == 'G' and Sequence[End_Front] == 'U'):
                        Energy_Int += 2.6

                    if (Sequence[Start] == 'U' and Sequence[End_Front] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[Start] == 'U' and Sequence[End_Front] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[Start] == 'U' and Sequence[End_Front] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[Start] == 'U' and Sequence[End_Front] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[End] == 'C'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[End] == 'G'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.6

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[End] == 'U'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
            if (Sequence[Start - 1] == 'A' or Sequence[End + 1] == 'U'):
                if (Sequence[End] == 'A'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[End] == 'C'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[End] == 'G'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[End] == 'U'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
            if (Sequence[Start - 1] == 'C' or Sequence[End + 1] == 'G'):
                if (Sequence[End] == 'A'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'C'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'G'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'U'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
            if (Sequence[Start - 1] == 'G' or Sequence[End + 1] == 'C'):
                if (Sequence[End] == 'A'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'C'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'G'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'U'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
        if (Sequence[End_Front + 1] == 'A' or Sequence[Start_Rear - 1] == 'U'):
            if (Sequence[Start - 1] == 'U' or Sequence[End + 1] == 'A'):
                if (Sequence[End] == 'A'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[End] == 'C'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[End] == 'G'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.6

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[End] == 'U'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
            if (Sequence[Start - 1] == 'A' or Sequence[End + 1] == 'U'):
                if (Sequence[End] == 'A'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[End] == 'C'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[End] == 'G'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.6

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.6
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.7
                if (Sequence[End] == 'U'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.7
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
            if (Sequence[Start - 1] == 'C' or Sequence[End + 1] == 'G'):
                if (Sequence[End] == 'A'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'C'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'G'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'U'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
            if (Sequence[Start - 1] == 'G' or Sequence[End + 1] == 'C'):
                if (Sequence[End] == 'A'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'C'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'G'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'U'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
        if (Sequence[End_Front + 1] == 'C' or Sequence[Start_Rear - 1] == 'G'):
            if (Sequence[Start - 1] == 'U' or Sequence[End + 1] == 'A'):
                if (Sequence[End] == 'A'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'C'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'G'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'U'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
            if (Sequence[Start - 1] == 'A' or Sequence[End + 1] == 'U'):
                if (Sequence[End] == 'A'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'C'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'G'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'U'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
            if (Sequence[Start - 1] == 'C' or Sequence[End + 1] == 'G'):
                if (Sequence[End] == 'A'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 2.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[End] == 'C'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[End] == 'G'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 1.1

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[End] == 'U'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 1.5

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 1.5

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.5

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 1.5
            if (Sequence[Start - 1] == 'G' or Sequence[End + 1] == 'C'):
                if (Sequence[End] == 'A'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[End] == 'C'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[End] == 'G'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[End] == 'U'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 1.5

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 1.5

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.5

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 1.5
        if (Sequence[End_Front + 1] == 'G' or Sequence[Start_Rear - 1] == 'C'):
            if (Sequence[Start - 1] == 'U' or Sequence[End + 1] == 'A'):
                if (Sequence[End] == 'A'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'C'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'G'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'U'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
            if (Sequence[Start - 1] == 'A' or Sequence[End + 1] == 'U'):
                if (Sequence[End] == 'A'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'C'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'G'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.9

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.9
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 3.0
                if (Sequence[End] == 'U'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 3.0
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.2

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.2
            if (Sequence[Start - 1] == 'C' or Sequence[End + 1] == 'G'):
                if (Sequence[End] == 'A'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[End] == 'C'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[End] == 'G'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 1.1

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[End] == 'U'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 1.5

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 1.5

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.5

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 1.5
            if (Sequence[Start - 1] == 'G' or Sequence[End + 1] == 'C'):
                if (Sequence[End] == 'A'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 2.5
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 1.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 0.8
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[End] == 'C'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 2.5
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 2.5
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[End] == 'G'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 1.7
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 0.8
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 1.2
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.1

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.1
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 2.3
                if (Sequence[End] == 'U'):
                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'A'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'A'):
                        Energy_Int += 1.5

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'C'):
                        Energy_Int += 2.2
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'C'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'C'):
                        Energy_Int += 1.5

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'G'):
                        Energy_Int += 2.3
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'G'):
                        Energy_Int += 1.5

                    if (Sequence[End_Front] == 'A' and Sequence[Start] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End_Front] == 'C' and Sequence[Start] == 'U'):
                        Energy_Int += 1.7
                    if (Sequence[End_Front] == 'G' and Sequence[Start] == 'U'):
                        Energy_Int += 1.5
                    if (Sequence[End_Front] == 'U' and Sequence[Start] == 'U'):
                        Energy_Int += 1.4
    elif(Length_Front == 1 and Length_Rear == 1):
        if(Sequence[Start - 1] == 'A' or Sequence[End + 1] == 'U'):
            if(Sequence[End_Front + 1] == 'A' or Sequence[Start_Rear - 1] == 'U'):
                if(Sequence[Start] == 'A' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.9
                if(Sequence[Start] == 'A' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.9
                if(Sequence[Start] == 'A' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.9
                if(Sequence[Start] == 'A' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.9

                if(Sequence[Start] == 'C' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.9
                if(Sequence[Start] == 'C' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.9
                if(Sequence[Start] == 'C' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.9
                if(Sequence[Start] == 'C' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.9

                if(Sequence[Start] == 'G' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.9
                if(Sequence[Start] == 'G' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.9
                if(Sequence[Start] == 'G' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += -0.7
                if(Sequence[Start] == 'G' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.9

                if(Sequence[Start] == 'U' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.9
                if(Sequence[Start] == 'U' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.9
                if(Sequence[Start] == 'U' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.9
                if(Sequence[Start] == 'U' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.5
            if (Sequence[End_Front + 1] == 'U' or Sequence[Start_Rear - 1] == 'A'):
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.9

                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.9

                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += -0.7
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.9

                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2
            if (Sequence[End_Front + 1] == 'G' or Sequence[Start_Rear - 1] == 'C'):
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += -1.4
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 0.8
            if (Sequence[End_Front + 1] == 'C' or Sequence[Start_Rear - 1] == 'G'):
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += -1.4
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 0.8
        elif (Sequence[Start - 1] == 'U' or Sequence[End + 1] == 'A'):
            if (Sequence[End_Front + 1] == 'A' or Sequence[Start_Rear - 1] == 'U'):
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.9

                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.9

                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += -0.7
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.9

                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.7
            if (Sequence[End_Front + 1] == 'U' or Sequence[Start_Rear - 1] == 'A'):
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.9

                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.9

                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += -0.7
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.9

                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.9
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.5
            if (Sequence[End_Front + 1] == 'G' or Sequence[Start_Rear - 1] == 'C'):
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += -1.4
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2
            if (Sequence[End_Front + 1] == 'C' or Sequence[Start_Rear - 1] == 'G'):
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += -1.4
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2
        elif (Sequence[Start - 1] == 'G' or Sequence[End + 1] == 'C'):
            if (Sequence[End_Front + 1] == 'A' or Sequence[Start_Rear - 1] == 'U'):
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += -1.4
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2
            if (Sequence[End_Front + 1] == 'U' or Sequence[Start_Rear - 1] == 'A'):
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += -1.4
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 0.8
            if (Sequence[End_Front + 1] == 'G' or Sequence[Start_Rear - 1] == 'C'):
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 0.9
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 0.3
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += -0.1
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 0.5

                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += -0.4
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 0

                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += -2.2
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 0.5

                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 0.6
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += -0.1
            if (Sequence[End_Front + 1] == 'C' or Sequence[Start_Rear - 1] == 'G'):
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 0.8
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 0.5

                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 0.5

                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += -2.3
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 0.5

                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += -0.6
        elif (Sequence[Start - 1] == 'C' or Sequence[End + 1] == 'G'):
            if (Sequence[End_Front + 1] == 'A' or Sequence[Start_Rear - 1] == 'U'):
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += -1.4
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2
            if (Sequence[End_Front + 1] == 'U' or Sequence[Start_Rear - 1] == 'A'):
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += -1.4
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 1.2

                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 1.2
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 0.8
            if (Sequence[End_Front + 1] == 'G' or Sequence[Start_Rear - 1] == 'C'):
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 0.9
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 0.5

                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 0.5

                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += -1.4
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 0.5

                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 0.4
            if (Sequence[End_Front + 1] == 'C' or Sequence[Start_Rear - 1] == 'G'):
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 0.9
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += -0.4
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'A' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 0.5

                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 0.3
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'C' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 0.6

                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += -0.1
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += -2.2
                if (Sequence[Start] == 'G' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += 0.5

                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'A'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'C'):
                    Energy_Int += 0
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'G'):
                    Energy_Int += 0.5
                if (Sequence[Start] == 'U' and Sequence[Start_Rear] == 'U'):
                    Energy_Int += -0.1
    else:
        if(Length_Front + Length_Rear == 4):
            Energy_Int += 1.1
        elif(Length_Front + Length_Rear == 5):
            Energy_Int += 2.0
        elif (Length_Front + Length_Rear == 6):
            Energy_Int += 2.0
        else:
            Eng_Tem = 2.0 + 1.08 * math.log((Length_Front + Length_Rear) / 6, math.e)
            Energy_Int += Eng_Tem
        Energy_Int += 0.6*abs(Length_Front-Length_Rear)
        if(Sequence[Start - 1] == 'A' or Sequence[Start - 1] == 'U'): #A,U终端惩罚
            Energy_Int += 0.7
        if(Sequence[End_Front + 1] == 'A' or Sequence[End_Front + 1] == 'U'): #A,U终端惩罚
            Energy_Int += 0.7
        if(Length_Front == 1 or Length_Rear == 1): #错配
            Energy_Int += 0
        elif(Length_Front == 2 and Length_Rear == 3):
            if(Sequence[Start] == 'A' and Sequence[End] == 'G'):
                Energy_Int += -0.5
            if(Sequence[Start] == 'G' and Sequence[End] == 'A'):
                Energy_Int += -1.1
            if(Sequence[Start] == 'G' and Sequence[End] == 'G'):
                Energy_Int += -0.8
            if(Sequence[Start] == 'U' and Sequence[End] == 'U'):
                Energy_Int += -0.4

            if(Sequence[End_Front] == 'A' and Sequence[Start_Rear] == 'G'):
                Energy_Int += -0.5
            if(Sequence[End_Front] == 'G' and Sequence[Start_Rear] == 'A'):
                Energy_Int += -1.1
            if(Sequence[End_Front] == 'G' and Sequence[Start_Rear] == 'G'):
                Energy_Int += -0.8
            if(Sequence[End_Front] == 'U' and Sequence[Start_Rear] == 'U'):
                Energy_Int += -0.4
        else:
            if (Sequence[Start] == 'A' and Sequence[End] == 'G'):
                Energy_Int += -0.8
            if (Sequence[Start] == 'G' and Sequence[End] == 'A'):
                Energy_Int += -1.0
            if (Sequence[Start] == 'G' and Sequence[End] == 'G'):
                Energy_Int += -1.2
            if (Sequence[Start] == 'U' and Sequence[End] == 'U'):
                Energy_Int += -0.7

            if (Sequence[End_Front] == 'A' and Sequence[Start_Rear] == 'G'):
                Energy_Int += -0.8
            if (Sequence[End_Front] == 'G' and Sequence[Start_Rear] == 'A'):
                Energy_Int += -1.0
            if (Sequence[End_Front] == 'G' and Sequence[Start_Rear] == 'G'):
                Energy_Int += -1.2
            if (Sequence[End_Front] == 'U' and Sequence[Start_Rear] == 'U'):
                Energy_Int += -0.7
    Energy_Int -= 4.09 #减去一个茎区的初始值
    if(Sequence[Start - 1] == 'A' or Sequence[Start - 1] == 'U'):
        Energy_Int -= 0.45 # 减去茎区的两个终端惩罚
    if(Sequence[End_Front + 1] == 'A' or Sequence[End_Front + 1] == 'U'):
        Energy_Int -= 0.45
    return Energy_Int

'''def Mul_Energy(Start, End, Structure_Nest, RNA_Sequence): # 带Dangling链的多分支环能量
    k = Start
    Number_Nest = 1
    Danging_Energy = 0

    # 多分支环的第一个茎的3’端
    if(RNA_Sequence[Start] == 'A'):
        if(RNA_Sequence[Start-1] == 'A'):
            Danging_Energy += -0.8
        elif(RNA_Sequence[Start-1] == 'U'):
            Danging_Energy += -0.7
        elif (RNA_Sequence[Start - 1] == 'G'):
            Danging_Energy += -1.1
        else:
            Danging_Energy += -1.7
    elif(RNA_Sequence[Start] == 'U'):
        if (RNA_Sequence[Start - 1] == 'A'):
            Danging_Energy += -0.6
        elif (RNA_Sequence[Start - 1] == 'U'):
            Danging_Energy += -0.1
        elif (RNA_Sequence[Start - 1] == 'G'):
            Danging_Energy += -0.6
        else:
            Danging_Energy += -1.2
    elif(RNA_Sequence[Start] == 'G'):
        if (RNA_Sequence[Start - 1] == 'A'):
            Danging_Energy += -0.8
        elif (RNA_Sequence[Start - 1] == 'U'):
            Danging_Energy += -0.7
        elif (RNA_Sequence[Start - 1] == 'G'):
            Danging_Energy += -1.3
        else:
            Danging_Energy += -1.7
    else:
        if (RNA_Sequence[Start - 1] == 'A'):
            Danging_Energy += -0.5
        elif (RNA_Sequence[Start - 1] == 'U'):
            Danging_Energy += -0.1
        elif (RNA_Sequence[Start - 1] == 'G'):
            Danging_Energy += -0.4
        else:
            Danging_Energy += -0.8
    # 多分支环的第一个茎的5’端
    if (RNA_Sequence[End] == 'A'):
        if (RNA_Sequence[End + 1] == 'A'):
            Danging_Energy += -0.3
        elif (RNA_Sequence[End + 1] == 'U'):
            Danging_Energy += -0.3
        elif (RNA_Sequence[End + 1] == 'G'):
            Danging_Energy += -0.2
        else:
            Danging_Energy += -0.5
    elif (RNA_Sequence[End] == 'U'):
        if (RNA_Sequence[End + 1] == 'A'):
            Danging_Energy += -0.2
        elif (RNA_Sequence[End + 1] == 'U'):
            Danging_Energy += -0.2
        elif (RNA_Sequence[End + 1] == 'G'):
            Danging_Energy += 0
        else:
            Danging_Energy += -0.1
    elif (RNA_Sequence[End] == 'G'):
        if (RNA_Sequence[End + 1] == 'A'):
            Danging_Energy += -0.4
        elif (RNA_Sequence[End + 1] == 'U'):
            Danging_Energy += -0.2
        elif (RNA_Sequence[End + 1] == 'G'):
            Danging_Energy += 0
        else:
            Danging_Energy += -0.2
    else:
        if (RNA_Sequence[End + 1] == 'A'):
            Danging_Energy += -0.3
        elif (RNA_Sequence[End + 1] == 'U'):
            Danging_Energy += -0.1
        elif (RNA_Sequence[End + 1] == 'G'):
            Danging_Energy += -0.3
        else:
            Danging_Energy += -0.3
    while(k <= End):
        if(Structure_Nest[k] > 0):
            #多分支环的其余茎的3’端
            if (RNA_Sequence[k-1] == 'A'):
                if (RNA_Sequence[k] == 'A'):
                    Danging_Energy += -0.8
                elif (RNA_Sequence[k] == 'U'):
                    Danging_Energy += -0.7
                elif (RNA_Sequence[k] == 'G'):
                    Danging_Energy += -1.1
                else:
                    Danging_Energy += -1.7
            elif (RNA_Sequence[k-1] == 'U'):
                if (RNA_Sequence[k] == 'A'):
                    Danging_Energy += -0.6
                elif (RNA_Sequence[k] == 'U'):
                    Danging_Energy += -0.1
                elif (RNA_Sequence[k] == 'G'):
                    Danging_Energy += -0.6
                else:
                    Danging_Energy += -1.2
            elif (RNA_Sequence[k-1] == 'G'):
                if (RNA_Sequence[k] == 'A'):
                    Danging_Energy += -0.8
                elif (RNA_Sequence[k] == 'U'):
                    Danging_Energy += -0.7
                elif (RNA_Sequence[k] == 'G'):
                    Danging_Energy += -1.3
                else:
                    Danging_Energy += -1.7
            else:
                if (RNA_Sequence[k] == 'A'):
                    Danging_Energy += -0.5
                elif (RNA_Sequence[k] == 'U'):
                    Danging_Energy += -0.1
                elif (RNA_Sequence[k] == 'G'):
                    Danging_Energy += -0.4
                else:
                    Danging_Energy += -0.8
            Number_Nest += 1
            k = Structure_Nest[k] + 1

            #多分支环的其余茎的5’端
            if (RNA_Sequence[k] == 'A'):
                if (RNA_Sequence[k-1] == 'A'):
                    Danging_Energy += -0.3
                elif (RNA_Sequence[k-1] == 'U'):
                    Danging_Energy += -0.3
                elif (RNA_Sequence[k-1] == 'G'):
                    Danging_Energy += -0.2
                else:
                    Danging_Energy += -0.5
            elif (RNA_Sequence[k] == 'U'):
                if (RNA_Sequence[k-1] == 'A'):
                    Danging_Energy += -0.2
                elif (RNA_Sequence[k-1] == 'U'):
                    Danging_Energy += -0.2
                elif (RNA_Sequence[k-1] == 'G'):
                    Danging_Energy += 0
                else:
                    Danging_Energy += -0.1
            elif (RNA_Sequence[k] == 'G'):
                if (RNA_Sequence[k-1] == 'A'):
                    Danging_Energy += -0.4
                elif (RNA_Sequence[k-1] == 'U'):
                    Danging_Energy += -0.2
                elif (RNA_Sequence[k-1] == 'G'):
                    Danging_Energy += 0
                else:
                    Danging_Energy += -0.2
            else:
                if (RNA_Sequence[k-1] == 'A'):
                    Danging_Energy += -0.3
                elif (RNA_Sequence[k-1] == 'U'):
                    Danging_Energy += -0.1
                elif (RNA_Sequence[k-1] == 'G'):
                    Danging_Energy += -0.3
                else:
                    Danging_Energy += -0.3
        else:
            k += 1

    Energy_Mul = 3.4 + 0.4*Number_Nest + Danging_Energy
    return Energy_Mul
'''

def Mul_Energy(Start, End, Structure_Nest, RNA_Sequence): # 带Dangling链的多分支环能量
    # 已经验证
    k = Start
    Number_Nest = 1
    Number_Unpaired = 0
    Energy_Mul = 0
    List_Mark = [0]*len(RNA_Sequence)
    # 多分支环的第一个茎的3’端
    if(Structure_Nest[Start] == -1 and Structure_Nest[End] == -1): # 此时按照错配算
        if (RNA_Sequence[Start - 1] == 'A' and RNA_Sequence[End + 1] == 'U'):

            if (RNA_Sequence[Start] == 'A' and RNA_Sequence[End] == 'A'):
                Energy_Mul += -0.8
            if (RNA_Sequence[Start] == 'A' and RNA_Sequence[End] == 'C'):
                Energy_Mul += -1.0
            if (RNA_Sequence[Start] == 'A' and RNA_Sequence[End] == 'G'):
                Energy_Mul += -0.8
            if (RNA_Sequence[Start] == 'A' and RNA_Sequence[End] == 'U'):
                Energy_Mul += -1.0

            if (RNA_Sequence[Start] == 'C' and RNA_Sequence[End] == 'A'):
                Energy_Mul += -0.6
            if (RNA_Sequence[Start] == 'C' and RNA_Sequence[End] == 'C'):
                Energy_Mul += -0.7
            if (RNA_Sequence[Start] == 'C' and RNA_Sequence[End] == 'G'):
                Energy_Mul += -0.6
            if (RNA_Sequence[Start] == 'C' and RNA_Sequence[End] == 'U'):
                Energy_Mul += -0.7

            if (RNA_Sequence[Start] == 'G' and RNA_Sequence[End] == 'A'):
                Energy_Mul += -0.8
            if (RNA_Sequence[Start] == 'G' and RNA_Sequence[End] == 'C'):
                Energy_Mul += -1.0
            if (RNA_Sequence[Start] == 'G' and RNA_Sequence[End] == 'G'):
                Energy_Mul += -0.8
            if (RNA_Sequence[Start] == 'G' and RNA_Sequence[End] == 'U'):
                Energy_Mul += -1.0

            if (RNA_Sequence[Start] == 'U' and RNA_Sequence[End] == 'A'):
                Energy_Mul += -0.6
            if (RNA_Sequence[Start] == 'U' and RNA_Sequence[End] == 'C'):
                Energy_Mul += -0.8
            if (RNA_Sequence[Start] == 'U' and RNA_Sequence[End] == 'G'):
                Energy_Mul += -0.6
            if (RNA_Sequence[Start] == 'U' and RNA_Sequence[End] == 'U'):
                Energy_Mul += -0.8
        if (RNA_Sequence[Start - 1] == 'U' and RNA_Sequence[End + 1] == 'A'):

            if (RNA_Sequence[Start] == 'A' and RNA_Sequence[End] == 'A'):
                Energy_Mul += -1.0
            if (RNA_Sequence[Start] == 'A' and RNA_Sequence[End] == 'C'):
                Energy_Mul += -0.8
            if (RNA_Sequence[Start] == 'A' and RNA_Sequence[End] == 'G'):
                Energy_Mul += -1.1
            if (RNA_Sequence[Start] == 'A' and RNA_Sequence[End] == 'U'):
                Energy_Mul += -0.8

            if (RNA_Sequence[Start] == 'C' and RNA_Sequence[End] == 'A'):
                Energy_Mul += -0.7
            if (RNA_Sequence[Start] == 'C' and RNA_Sequence[End] == 'C'):
                Energy_Mul += -0.6
            if (RNA_Sequence[Start] == 'C' and RNA_Sequence[End] == 'G'):
                Energy_Mul += -0.7
            if (RNA_Sequence[Start] == 'C' and RNA_Sequence[End] == 'U'):
                Energy_Mul += -0.5

            if (RNA_Sequence[Start] == 'G' and RNA_Sequence[End] == 'A'):
                Energy_Mul += -1.1
            if (RNA_Sequence[Start] == 'G' and RNA_Sequence[End] == 'C'):
                Energy_Mul += -0.8
            if (RNA_Sequence[Start] == 'G' and RNA_Sequence[End] == 'G'):
                Energy_Mul += -1.2
            if (RNA_Sequence[Start] == 'G' and RNA_Sequence[End] == 'U'):
                Energy_Mul += -0.8

            if (RNA_Sequence[Start] == 'U' and RNA_Sequence[End] == 'A'):
                Energy_Mul += -0.7
            if (RNA_Sequence[Start] == 'U' and RNA_Sequence[End] == 'C'):
                Energy_Mul += -0.6
            if (RNA_Sequence[Start] == 'U' and RNA_Sequence[End] == 'G'):
                Energy_Mul += -0.7
            if (RNA_Sequence[Start] == 'U' and RNA_Sequence[End] == 'U'):
                Energy_Mul += -0.5
        if (RNA_Sequence[Start - 1] == 'G' and RNA_Sequence[End + 1] == 'C'):

            if (RNA_Sequence[Start] == 'A' and RNA_Sequence[End] == 'A'):
                Energy_Mul += -1.1
            if (RNA_Sequence[Start] == 'A' and RNA_Sequence[End] == 'C'):
                Energy_Mul += -1.5
            if (RNA_Sequence[Start] == 'A' and RNA_Sequence[End] == 'G'):
                Energy_Mul += -1.3
            if (RNA_Sequence[Start] == 'A' and RNA_Sequence[End] == 'U'):
                Energy_Mul += -1.5

            if (RNA_Sequence[Start] == 'C' and RNA_Sequence[End] == 'A'):
                Energy_Mul += -1.1
            if (RNA_Sequence[Start] == 'C' and RNA_Sequence[End] == 'C'):
                Energy_Mul += -0.7
            if (RNA_Sequence[Start] == 'C' and RNA_Sequence[End] == 'G'):
                Energy_Mul += -1.1
            if (RNA_Sequence[Start] == 'C' and RNA_Sequence[End] == 'U'):
                Energy_Mul += -0.5

            if (RNA_Sequence[Start] == 'G' and RNA_Sequence[End] == 'A'):
                Energy_Mul += -1.6
            if (RNA_Sequence[Start] == 'G' and RNA_Sequence[End] == 'C'):
                Energy_Mul += -1.5
            if (RNA_Sequence[Start] == 'G' and RNA_Sequence[End] == 'G'):
                Energy_Mul += -1.4
            if (RNA_Sequence[Start] == 'G' and RNA_Sequence[End] == 'U'):
                Energy_Mul += -1.5

            if (RNA_Sequence[Start] == 'U' and RNA_Sequence[End] == 'A'):
                Energy_Mul += -1.1
            if (RNA_Sequence[Start] == 'U' and RNA_Sequence[End] == 'C'):
                Energy_Mul += -1.0
            if (RNA_Sequence[Start] == 'U' and RNA_Sequence[End] == 'G'):
                Energy_Mul += -1.1
            if (RNA_Sequence[Start] == 'U' and RNA_Sequence[End] == 'U'):
                Energy_Mul += -0.7
        if (RNA_Sequence[Start - 1] == 'C' and RNA_Sequence[End + 1] == 'G'):

            if (RNA_Sequence[Start] == 'A' and RNA_Sequence[End] == 'A'):
                Energy_Mul += -1.5
            if (RNA_Sequence[Start] == 'A' and RNA_Sequence[End] == 'C'):
                Energy_Mul += -1.5
            if (RNA_Sequence[Start] == 'A' and RNA_Sequence[End] == 'G'):
                Energy_Mul += -1.4
            if (RNA_Sequence[Start] == 'A' and RNA_Sequence[End] == 'U'):
                Energy_Mul += -1.5

            if (RNA_Sequence[Start] == 'C' and RNA_Sequence[End] == 'A'):
                Energy_Mul += -1.0
            if (RNA_Sequence[Start] == 'C' and RNA_Sequence[End] == 'C'):
                Energy_Mul += -1.1
            if (RNA_Sequence[Start] == 'C' and RNA_Sequence[End] == 'G'):
                Energy_Mul += -1.0
            if (RNA_Sequence[Start] == 'C' and RNA_Sequence[End] == 'U'):
                Energy_Mul += -0.8

            if (RNA_Sequence[Start] == 'G' and RNA_Sequence[End] == 'A'):
                Energy_Mul += -1.4
            if (RNA_Sequence[Start] == 'G' and RNA_Sequence[End] == 'C'):
                Energy_Mul += -1.5
            if (RNA_Sequence[Start] == 'G' and RNA_Sequence[End] == 'G'):
                Energy_Mul += -1.6
            if (RNA_Sequence[Start] == 'G' and RNA_Sequence[End] == 'U'):
                Energy_Mul += -1.5

            if (RNA_Sequence[Start] == 'U' and RNA_Sequence[End] == 'A'):
                Energy_Mul += -1.0
            if (RNA_Sequence[Start] == 'U' and RNA_Sequence[End] == 'C'):
                Energy_Mul += -1.4
            if (RNA_Sequence[Start] == 'U' and RNA_Sequence[End] == 'G'):
                Energy_Mul += -1.0
            if (RNA_Sequence[Start] == 'U' and RNA_Sequence[End] == 'U'):
                Energy_Mul += -1.2
        List_Mark[Start] = 1
        List_Mark[End] = 1
    elif(Structure_Nest[Start] == -1): # 5端有Dangling链
        if (RNA_Sequence[Start - 1] == 'A' and RNA_Sequence[End + 1] == 'U'):
            if(RNA_Sequence[Start] == 'A'):
                Energy_Mul  += -0.8
            if(RNA_Sequence[Start] == 'C'):
                Energy_Mul  += -0.5
            if(RNA_Sequence[Start] == 'G'):
                Energy_Mul  += -0.8
            if(RNA_Sequence[Start] == 'U'):
                Energy_Mul  += -0.6
        if (RNA_Sequence[Start - 1] == 'U' and RNA_Sequence[End + 1] == 'A'):
            if(RNA_Sequence[Start] == 'A'):
                Energy_Mul  += -0.7
            if(RNA_Sequence[Start] == 'C'):
                Energy_Mul  += -0.1
            if(RNA_Sequence[Start] == 'G'):
                Energy_Mul  += -0.7
            if(RNA_Sequence[Start] == 'U'):
                Energy_Mul  += -0.1
        if (RNA_Sequence[Start - 1] == 'G' and RNA_Sequence[End + 1] == 'C'):
            if(RNA_Sequence[Start] == 'A'):
                Energy_Mul  += -1.1
            if(RNA_Sequence[Start] == 'C'):
                Energy_Mul  += -0.4
            if(RNA_Sequence[Start] == 'G'):
                Energy_Mul  += -1.3
            if(RNA_Sequence[Start] == 'U'):
                Energy_Mul  += -0.6
        if (RNA_Sequence[Start - 1] == 'C' and RNA_Sequence[End + 1] == 'G'):
            if(RNA_Sequence[Start] == 'A'):
                Energy_Mul  += -1.7
            if(RNA_Sequence[Start] == 'C'):
                Energy_Mul  += -0.8
            if(RNA_Sequence[Start] == 'G'):
                Energy_Mul  += -1.7
            if(RNA_Sequence[Start] == 'U'):
                Energy_Mul  += -1.2
        List_Mark[Start] = 1
    elif(Structure_Nest[End] == -1): #3端有Dangling链
        if (RNA_Sequence[Start - 1] == 'A' and RNA_Sequence[End + 1] == 'U'):
            if(RNA_Sequence[End] == 'A'):
                Energy_Mul  += -0.3
            if(RNA_Sequence[End] == 'C'):
                Energy_Mul  += -0.1
            if(RNA_Sequence[End] == 'G'):
                Energy_Mul  += -0.2
            if(RNA_Sequence[End] == 'U'):
                Energy_Mul  += -0.2
        if (RNA_Sequence[Start - 1] == 'U' and RNA_Sequence[End + 1] == 'A'):
            if(RNA_Sequence[End] == 'A'):
                Energy_Mul  += -0.3
            if(RNA_Sequence[End] == 'C'):
                Energy_Mul  += -0.3
            if(RNA_Sequence[End] == 'G'):
                Energy_Mul  += -0.4
            if(RNA_Sequence[End] == 'U'):
                Energy_Mul  += -0.2
        if (RNA_Sequence[Start - 1] == 'G' and RNA_Sequence[End + 1] == 'C'):
            if(RNA_Sequence[End] == 'A'):
                Energy_Mul  += -0.5
            if(RNA_Sequence[End] == 'C'):
                Energy_Mul  += -0.3
            if(RNA_Sequence[End] == 'G'):
                Energy_Mul  += -0.2
            if(RNA_Sequence[End] == 'U'):
                Energy_Mul  += -0.1
        if (RNA_Sequence[Start - 1] == 'C' and RNA_Sequence[End + 1] == 'G'):
            if(RNA_Sequence[End] == 'A'):
                Energy_Mul  += -0.2
            if(RNA_Sequence[End] == 'C'):
                Energy_Mul  += -0.3
            if(RNA_Sequence[End] == 'G'):
                Energy_Mul  += -0.0
            if(RNA_Sequence[End] == 'U'):
                Energy_Mul  += -0.0
        List_Mark[End] = 1
    while(k <= End): # 找其他的茎区环
        if(Structure_Nest[k] > 0): #找到了茎区
            Stem_Loop_Start = k-1 #
            Stem_Loop_End = Structure_Nest[k] + 1
            if((Structure_Nest[Stem_Loop_Start] == -1 and List_Mark[Stem_Loop_Start] != 1) and (Structure_Nest[Stem_Loop_End] == -1 and List_Mark[Stem_Loop_End] != 1)):
                #此时按照错配算
                if(RNA_Sequence[k] == 'A' and RNA_Sequence[Structure_Nest[k]] == 'U'):
                    if (RNA_Sequence[Stem_Loop_Start] == 'A' and RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -1.0
                    if (RNA_Sequence[Stem_Loop_Start] == 'A' and RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -0.7
                    if (RNA_Sequence[Stem_Loop_Start] == 'A' and RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -1.1
                    if (RNA_Sequence[Stem_Loop_Start] == 'A' and RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -0.7

                    if (RNA_Sequence[Stem_Loop_Start] == 'C' and RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -0.8
                    if (RNA_Sequence[Stem_Loop_Start] == 'C' and RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -0.6
                    if (RNA_Sequence[Stem_Loop_Start] == 'C' and RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -0.8
                    if (RNA_Sequence[Stem_Loop_Start] == 'C' and RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -0.6

                    if (RNA_Sequence[Stem_Loop_Start] == 'G' and RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -1.1
                    if (RNA_Sequence[Stem_Loop_Start] == 'G' and RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -0.7
                    if (RNA_Sequence[Stem_Loop_Start] == 'G' and RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -1.2
                    if (RNA_Sequence[Stem_Loop_Start] == 'G' and RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -0.7

                    if (RNA_Sequence[Stem_Loop_Start] == 'U' and RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -0.8
                    if (RNA_Sequence[Stem_Loop_Start] == 'U' and RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -0.5
                    if (RNA_Sequence[Stem_Loop_Start] == 'U' and RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -0.8
                    if (RNA_Sequence[Stem_Loop_Start] == 'U' and RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -0.5
                if (RNA_Sequence[k] == 'U' and RNA_Sequence[Structure_Nest[k]] == 'A'):
                    if (RNA_Sequence[Stem_Loop_Start] == 'A' and RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -0.8
                    if (RNA_Sequence[Stem_Loop_Start] == 'A' and RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -0.6
                    if (RNA_Sequence[Stem_Loop_Start] == 'A' and RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -0.8
                    if (RNA_Sequence[Stem_Loop_Start] == 'A' and RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -0.6

                    if (RNA_Sequence[Stem_Loop_Start] == 'C' and RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -1.0
                    if (RNA_Sequence[Stem_Loop_Start] == 'C' and RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -0.7
                    if (RNA_Sequence[Stem_Loop_Start] == 'C' and RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -1.0
                    if (RNA_Sequence[Stem_Loop_Start] == 'C' and RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -0.8

                    if (RNA_Sequence[Stem_Loop_Start] == 'G' and RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -0.8
                    if (RNA_Sequence[Stem_Loop_Start] == 'G' and RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -0.6
                    if (RNA_Sequence[Stem_Loop_Start] == 'G' and RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -0.8
                    if (RNA_Sequence[Stem_Loop_Start] == 'G' and RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -0.6

                    if (RNA_Sequence[Stem_Loop_Start] == 'U' and RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -1.0
                    if (RNA_Sequence[Stem_Loop_Start] == 'U' and RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -0.7
                    if (RNA_Sequence[Stem_Loop_Start] == 'U' and RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -1.0
                    if (RNA_Sequence[Stem_Loop_Start] == 'U' and RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -0.8
                if (RNA_Sequence[k] == 'G' and RNA_Sequence[Structure_Nest[k]] == 'C'):
                    if (RNA_Sequence[Stem_Loop_Start] == 'A' and RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -1.5
                    if (RNA_Sequence[Stem_Loop_Start] == 'A' and RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -1.0
                    if (RNA_Sequence[Stem_Loop_Start] == 'A' and RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -1.4
                    if (RNA_Sequence[Stem_Loop_Start] == 'A' and RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -1.0

                    if (RNA_Sequence[Stem_Loop_Start] == 'C' and RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -1.5
                    if (RNA_Sequence[Stem_Loop_Start] == 'C' and RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -1.1
                    if (RNA_Sequence[Stem_Loop_Start] == 'C' and RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -1.5
                    if (RNA_Sequence[Stem_Loop_Start] == 'C' and RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -1.4

                    if (RNA_Sequence[Stem_Loop_Start] == 'G' and RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -1.4
                    if (RNA_Sequence[Stem_Loop_Start] == 'G' and RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -1.0
                    if (RNA_Sequence[Stem_Loop_Start] == 'G' and RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -1.6
                    if (RNA_Sequence[Stem_Loop_Start] == 'G' and RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -1.0

                    if (RNA_Sequence[Stem_Loop_Start] == 'U' and RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -1.5
                    if (RNA_Sequence[Stem_Loop_Start] == 'U' and RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -0.8
                    if (RNA_Sequence[Stem_Loop_Start] == 'U' and RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -1.5
                    if (RNA_Sequence[Stem_Loop_Start] == 'U' and RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -1.2
                if (RNA_Sequence[k] == 'C' and RNA_Sequence[Structure_Nest[k]] == 'G'):
                    if (RNA_Sequence[Stem_Loop_Start] == 'A' and RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -1.1
                    if (RNA_Sequence[Stem_Loop_Start] == 'A' and RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -1.1
                    if (RNA_Sequence[Stem_Loop_Start] == 'A' and RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -1.6
                    if (RNA_Sequence[Stem_Loop_Start] == 'A' and RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -1.1

                    if (RNA_Sequence[Stem_Loop_Start] == 'C' and RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -1.5
                    if (RNA_Sequence[Stem_Loop_Start] == 'C' and RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -0.7
                    if (RNA_Sequence[Stem_Loop_Start] == 'C' and RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -1.5
                    if (RNA_Sequence[Stem_Loop_Start] == 'C' and RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -1.0

                    if (RNA_Sequence[Stem_Loop_Start] == 'G' and RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -1.3
                    if (RNA_Sequence[Stem_Loop_Start] == 'G' and RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -1.1
                    if (RNA_Sequence[Stem_Loop_Start] == 'G' and RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -1.4
                    if (RNA_Sequence[Stem_Loop_Start] == 'G' and RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -1.1

                    if (RNA_Sequence[Stem_Loop_Start] == 'U' and RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -1.5
                    if (RNA_Sequence[Stem_Loop_Start] == 'U' and RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -0.5
                    if (RNA_Sequence[Stem_Loop_Start] == 'U' and RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -1.5
                    if (RNA_Sequence[Stem_Loop_Start] == 'U' and RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -0.7
                List_Mark[Stem_Loop_Start] = 1
                List_Mark[Stem_Loop_End] = 1
            elif(Structure_Nest[Stem_Loop_Start] == -1 and List_Mark[Stem_Loop_Start] != 1):
                if (RNA_Sequence[k] == 'A' and RNA_Sequence[Structure_Nest[k]] == 'U'):
                    if (RNA_Sequence[Stem_Loop_Start] == 'A'):
                        Energy_Mul += -0.3
                    if (RNA_Sequence[Stem_Loop_Start] == 'C'):
                        Energy_Mul += -0.3
                    if (RNA_Sequence[Stem_Loop_Start] == 'G'):
                        Energy_Mul += -0.4
                    if (RNA_Sequence[Stem_Loop_Start] == 'U'):
                        Energy_Mul += -0.2
                if (RNA_Sequence[k] == 'U' and RNA_Sequence[Structure_Nest[k]] == 'A'):
                    if (RNA_Sequence[Stem_Loop_Start] == 'A'):
                        Energy_Mul += -0.3
                    if (RNA_Sequence[Stem_Loop_Start] == 'C'):
                        Energy_Mul += -0.1
                    if (RNA_Sequence[Stem_Loop_Start] == 'G'):
                        Energy_Mul += -0.2
                    if (RNA_Sequence[Stem_Loop_Start] == 'U'):
                        Energy_Mul += -0.2
                if (RNA_Sequence[k] == 'G' and RNA_Sequence[Structure_Nest[k]] == 'C'):
                    if (RNA_Sequence[Stem_Loop_Start] == 'A'):
                        Energy_Mul += -0.2
                    if (RNA_Sequence[Stem_Loop_Start] == 'C'):
                        Energy_Mul += -0.3
                    if (RNA_Sequence[Stem_Loop_Start] == 'G'):
                        Energy_Mul += 0
                    if (RNA_Sequence[Stem_Loop_Start] == 'U'):
                        Energy_Mul += 0
                if (RNA_Sequence[k] == 'C' and RNA_Sequence[Structure_Nest[k]] == 'G'):
                    if (RNA_Sequence[Stem_Loop_Start] == 'A'):
                        Energy_Mul += -0.5
                    if (RNA_Sequence[Stem_Loop_Start] == 'C'):
                        Energy_Mul += -0.3
                    if (RNA_Sequence[Stem_Loop_Start] == 'G'):
                        Energy_Mul += -0.2
                    if (RNA_Sequence[Stem_Loop_Start] == 'U'):
                        Energy_Mul += -0.1
                List_Mark[Stem_Loop_Start] = 1
            elif(Structure_Nest[Stem_Loop_End] == -1 and List_Mark[Stem_Loop_End] != 1):
                if (RNA_Sequence[k] == 'A' and RNA_Sequence[Structure_Nest[k]] == 'U'):
                    if (RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -0.7
                    if (RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -0.1
                    if (RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -0.7
                    if (RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -0.1
                if (RNA_Sequence[k] == 'U' and RNA_Sequence[Structure_Nest[k]] == 'A'):
                    if (RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -0.8
                    if (RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -0.5
                    if (RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -0.8
                    if (RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -0.6
                if (RNA_Sequence[k] == 'G' and RNA_Sequence[Structure_Nest[k]] == 'C'):
                    if (RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -1.7
                    if (RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -0.8
                    if (RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -1.7
                    if (RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -1.2
                if (RNA_Sequence[k] == 'C' and RNA_Sequence[Structure_Nest[k]] == 'G'):
                    if (RNA_Sequence[Stem_Loop_End] == 'A'):
                        Energy_Mul += -1.1
                    if (RNA_Sequence[Stem_Loop_End] == 'C'):
                        Energy_Mul += -0.4
                    if (RNA_Sequence[Stem_Loop_End] == 'G'):
                        Energy_Mul += -1.3
                    if (RNA_Sequence[Stem_Loop_End] == 'U'):
                        Energy_Mul += -0.6
                List_Mark[Stem_Loop_End] = 1
            Number_Nest += 1
            k = Structure_Nest[k] + 1
        else:
            Number_Unpaired += 1
            k += 1
    k1 = Start
    Number_Unpaired_List = []
    Num_Un = 0
    while(k1 <= End):

        if(Structure_Nest[k1] == -1):
            Num_Un += 1
            k1 += 1
        else:
            Number_Unpaired_List.append(Num_Un)
            Num_Un = 0
            k1 = Structure_Nest[k1] + 1
            if(k1 == End+1):
                Number_Unpaired_List.append(0)
    Sum_Asy = 0
    for unpair_index in range(len(Number_Unpaired_List)):# average asymmetry
        Front_In = (unpair_index + len(Number_Unpaired_List) -1)%len(Number_Unpaired_List)#循环队列
        Sum_Asy += abs(Number_Unpaired_List[Front_In] - Number_Unpaired_List[unpair_index])
    if(len(Number_Unpaired_List) != 0 and Sum_Asy/len(Number_Unpaired_List) < 2.0):
        Average = Sum_Asy/len(Number_Unpaired_List)
    else:
        Average = 2.0
    Energy_Mul += 9.25 + 0.91*Average - 0.63*Number_Nest
    if(Number_Nest == 3 and Number_Unpaired < 2): #三个茎区两个未配对碱基
        Energy_Mul += 3.14
    return Energy_Mul

def Dangling_Energy(Structure_Nest, RNA_Sequence):
    Danging_Energy = 0
    for i in range(len(Structure_Nest)):
        if(Structure_Nest[i] > 0 and i > 0): # 此时存在5’端Dangling链
            if (RNA_Sequence[i-1] == 'A'):
                if (RNA_Sequence[i] == 'A'):
                    Danging_Energy += -0.8
                elif (RNA_Sequence[i] == 'U'):
                    Danging_Energy += -0.7
                elif (RNA_Sequence[i] == 'G'):
                    Danging_Energy += -1.1
                else:
                    Danging_Energy += -1.7
            elif (RNA_Sequence[i-1] == 'U'):
                if (RNA_Sequence[i] == 'A'):
                    Danging_Energy += -0.6
                elif (RNA_Sequence[i] == 'U'):
                    Danging_Energy += -0.1
                elif (RNA_Sequence[i] == 'G'):
                    Danging_Energy += -0.6
                else:
                    Danging_Energy += -1.2
            elif (RNA_Sequence[i-1] == 'G'):
                if (RNA_Sequence[i] == 'A'):
                    Danging_Energy += -0.8
                elif (RNA_Sequence[i] == 'U'):
                    Danging_Energy += -0.7
                elif (RNA_Sequence[i] == 'G'):
                    Danging_Energy += -1.3
                else:
                    Danging_Energy += -1.7
            else:
                if (RNA_Sequence[i] == 'A'):
                    Danging_Energy += -0.5
                elif (RNA_Sequence[i] == 'U'):
                    Danging_Energy += -0.1
                elif (RNA_Sequence[i] == 'G'):
                    Danging_Energy += -0.4
                else:
                    Danging_Energy += -0.8
        if(Structure_Nest[i] > 0):
            break
    Index = len(Structure_Nest)-1
    while(Index > 0):
        if(Structure_Nest[Index] > 0 and Index < len(Structure_Nest)-1):
            # 多分支环的其余茎的5’端
            if (RNA_Sequence[Index + 1] == 'A'):
                if (RNA_Sequence[Index] == 'A'):
                    Danging_Energy += -0.3
                elif (RNA_Sequence[Index] == 'U'):
                    Danging_Energy += -0.3
                elif (RNA_Sequence[Index] == 'G'):
                    Danging_Energy += -0.2
                else:
                    Danging_Energy += -0.5
            elif (RNA_Sequence[Index + 1] == 'U'):
                if (RNA_Sequence[Index] == 'A'):
                    Danging_Energy += -0.2
                elif (RNA_Sequence[Index] == 'U'):
                    Danging_Energy += -0.2
                elif (RNA_Sequence[Index] == 'G'):
                    Danging_Energy += 0
                else:
                    Danging_Energy += -0.1
            elif (RNA_Sequence[Index + 1] == 'G'):
                if (RNA_Sequence[Index] == 'A'):
                    Danging_Energy += -0.4
                elif (RNA_Sequence[Index] == 'U'):
                    Danging_Energy += -0.2
                elif (RNA_Sequence[Index] == 'G'):
                    Danging_Energy += 0
                else:
                    Danging_Energy += -0.2
            else:
                if (RNA_Sequence[Index] == 'A'):
                    Danging_Energy += -0.3
                elif (RNA_Sequence[Index] == 'U'):
                    Danging_Energy += -0.1
                elif (RNA_Sequence[Index] == 'G'):
                    Danging_Energy += -0.3
                else:
                    Danging_Energy += -0.2
        if (Structure_Nest[Index] > 0):
            break
        Index -= 1
    return Danging_Energy

def Loop_Type(Structure_Nest, Stem_List): #嵌套环区标记
    # 0是发夹环、1是凸环、2是内环，3是多分支环
    Loop_Type_List = [4 for x in range(len(Structure_Nest))] #默认为当dangle链
    i = 0
    while(i < len(Stem_List)): # 对每一个茎区包含的环进行标记
        start = Stem_List[i][0] + Stem_List[i][2] -1
        end = Stem_List[i][1] - Stem_List[i][2] + 1
        num = 0
        Structure_Index = start+1
        while(Structure_Index < end):
            if(Structure_Nest[Structure_Index] != -1 and Structure_Index < Structure_Nest[Structure_Index]):
                num += 1
                Structure_Index = Structure_Nest[Structure_Index]
            Structure_Index += 1
        if(num == 0): #发卡环
            k = start+1
            while(k < end):
                Loop_Type_List[k] = 0
                k += 1
        elif(num == 1):
            if(Structure_Nest[start+1] !=-1 or Structure_Nest[end - 1] !=-1): #凸环
                k = start + 1
                while (k < end):
                    if(Structure_Nest[k] == -1):
                        Loop_Type_List[k] = 1
                    else:
                        k = Structure_Nest[k]
                    k += 1
            else: # 内环
                k = start + 1
                while (k < end):
                    if (Structure_Nest[k] == -1):
                        Loop_Type_List[k] = 2
                    else:
                        k = Structure_Nest[k]
                    k += 1
        else: # 多分支环
            k = start + 1
            while (k < end):
                if (Structure_Nest[k] == -1):
                    Loop_Type_List[k] = 3
                else:
                    k = Structure_Nest[k]
                k += 1
        i += 1
    for i in range(len(Structure_Nest)): # 非环区
        if(Structure_Nest[i] != -1):
            Loop_Type_List[i] = -1
    return Loop_Type_List

def Nest_Energy(Sequence_Energy, Structure_Nest, Stem_Nest):
    Energy_Nest = 0
    Loop_Type_List = Loop_Type(Structure_Nest, Stem_Nest)
    for i in range(len(Stem_Nest)): #计算出所有茎区的能量
        Energy_Nest += Energy_Stem(Stem_Nest[i], Sequence_Energy)
    j_nest = 0
    while(j_nest < len(Loop_Type_List)):

        if(Loop_Type_List[j_nest] == 0): #发卡环能量计算
            Start_Hair = j_nest # 发卡环起始
            End_Hair = Structure_Nest[j_nest-1]-1 # 发卡环终止
            Energy_Nest += Hair_Energy(Sequence_Energy, Start_Hair, End_Hair)
            number_pro = Start_Hair
            while(number_pro <= End_Hair): # 将计算过的发卡环置为-1
                Loop_Type_List[number_pro] = -1
                number_pro += 1

        if (Loop_Type_List[j_nest] == 1): # 凸环能量计算
            Start_Bul = j_nest # 凸环起始
            End_Bul = j_nest #  凸环终止
            while(Loop_Type_List[End_Bul] == 1):
                End_Bul += 1
            End_Bul -= 1
            Energy_Nest += Bulge_Energy(Sequence_Energy, Start_Bul, End_Bul, Structure_Nest)
            number_pro = Start_Bul
            while(number_pro <= End_Bul): # 将计算过得环置为-1，不影响其他环的计算
                Loop_Type_List[number_pro] = -1
                number_pro += 1

        if (Loop_Type_List[j_nest] == 2):  # 内环能量计算
            Start_Int = j_nest
            End_Int = Structure_Nest[j_nest - 1] - 1
            k = Start_Int
            while (Structure_Nest[k] < 0):  # 寻找凸环前一段的结束位置
                k += 1
            End_Front = k - 1  # 前一段的结束位置
            P = End_Int
            while (Structure_Nest[P] < 0):
                P -= 1
            Start_Rear = P + 1  # 后一段的起始位置
            Energy_Nest += Int_Energy(Sequence_Energy, Start_Int, End_Int, End_Front,Start_Rear)
            number_pro = Start_Int
            while (number_pro <= End_Front):
                Loop_Type_List[number_pro] = -1
                number_pro += 1
            number_pro = Start_Rear
            while (number_pro <= End_Int):
                Loop_Type_List[number_pro] = -1
                number_pro += 1

        if (Loop_Type_List[j_nest] == 3):  # 多分支环能量计算
            Start_Mul = j_nest
            End_Mul = Structure_Nest[j_nest - 1] - 1
            Energy_Nest += Mul_Energy(Start_Mul, End_Mul, Structure_Nest, Sequence_Energy)
            number_pro = Start_Mul
            while (number_pro <= End_Mul):
                if (Structure_Nest[number_pro] > 0):
                    number_pro = Structure_Nest[number_pro] + 1
                else:
                    Loop_Type_List[number_pro] = -1
                    number_pro += 1
        j_nest += 1
    #Energy_Nest += Dangling_Energy(Structure_Nest, Sequence_Energy)
    return Energy_Nest

#Sequence = 'UGCCGGUGGCCAUAGUGGAGAGGUAAUACCCGUUCCCAUUCCGAACACGGAAGUCAAGCUCUCUUACGUCGAUGAUACUGGGUUCGUCCCGGGAAAGUAGAUAGCUGCCGGCUU'
#Structure_Nest = [-1, -1, -1, -1, -1, -1, -1, 88, 87, -1, -1, -1, -1, 78, 77, 76, -1, -1, -1, 69, 68, 30, 29, -1, -1, -1, -1, -1, -1, 22, 21, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 60, 59, -1, -1, -1, -1, -1, -1, -1, -1, 50, 49, -1, -1, -1, -1, -1, -1, -1, 20, 19, -1, -1, -1, -1, -1, -1, 15, 14, 13, -1, -1, -1, -1, -1, -1, -1, -1, 8, 7, -1, -1, -1, -1, -1, -1, -1, -1, -1, 105, 104, -1, -1, -1, -1, 99, 98, -1, -1, -1, -1, -1, -1, -1, -1]
#Stem_Nest = [[21, 30, 2], [7, 88, 2], [49, 60, 2], [19, 69, 2], [98, 105, 2], [13, 78, 3]]

#Energy_Nest = Nest_Energy(Sequence, Structure_Nest, Stem_Nest)
#print(Energy_Nest)

#Sequence = 'UGCCGGUGGCCAUAGUGGAGAGGUAAUACCCGUUCCCAUUCCGAACACGGAAGUCAAGCUCUCUUACGUCGAUGAUACUGGGUUCGUCCCGGGAAAGUAGAUAGCUGCCGGCUU'
#Structure_Nest = [-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 63, 62, -1, -1, 54, 53, -1, -1, -1, -1, -1, -1, -1, -1, -1, 49, 48, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 29, 28, -1, -1, -1, 18, 17, -1, -1, -1, -1, -1, -1, -1, 14, 13, -1, -1, 109, 108, 100, 99, 87, 86, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 71, 70, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 69, 68, -1, -1, -1, -1, -1, -1, -1, 67, 66, -1, -1, -1, -1]
#Stem_Nest = [[13, 63, 2], [66, 109, 2], [70, 87, 2], [68, 100, 2], [17, 54, 2], [28, 49, 2]]
#Energy_Nest = Nest_Energy(Sequence, Structure_Nest, Stem_Nest)
#print(Energy_Nest)

#Sequence = 'CCGUUAGAUCAGAGGAUCGCUGGAGAGCCAGAGGUCCGUCAGAGGACGACGG'

#Structure_Nest = [51, 50, 49, 48, -1, -1, 17, 16, 15, 14, -1, -1, -1, -1, 9, 8, 7, 6, -1, 30, 29, 28, 27, -1, -1, -1, -1, 22, 21, 20, 19, -1, -1, -1, -1, -1, 47, 46, 45, 44, -1, -1, -1, -1, 39, 38, 37, 36, 3, 2, 1, 0]

#Energy_Mul = Mul_Energy(4, 47, Structure_Nest, Sequence)

#print(len(Sequence))
#print(len(Structure_Nest))
#print(Energy_Mul)

#Sequence = 'CACACCCCCCUGUG'
#Structure_Nest = [13, 12, 11, 10,-1, -1, -1, -1, -1, -1, 3, 2, 1, 0]
#Stem = [0, 13, 4]

#Energy = Energy_Stem(Stem, Sequence)
#print(Energy)
#Energy_Pair = Hair_Energy(Sequence, 4, 9)
#print(Energy_Pair)

#Sequence = 'GCCCGAGAGCGGC'
#Structure_Nest = [12, 11, 10, -1, 9, -1, -1, -1, -1, 4, 2, 1, 0]
#AA = Bulge_Energy(Sequence, 3, 3, Structure_Nest)
#print(AA)

#Sequence = 'CAGCGAGAGCGGAAAGUG'
#Structure_Nest = [17, 16, -1, 10, 9, -1, -1, -1, -1, 4, 3, -1, -1, -1, -1, -1, 1, 0]
#Energy_Int = Int_Energy(Sequence, 2, 15, 2, 11)
#print(Energy_Int)

#Seq = 'CAGACGAGAGCGGAUG'
#Structure_Nest = [15, 14, -1, -1, 11, 10, -1, -1, -1, -1, 5, 4, -1, -1, 1, 0]
#Energy_Int = Int_Energy(Seq, 2, 13, 3, 12)
#print(Energy_Int)

#Seq = 'CAGACGAGAGCGGAGUG'
#Structure_Nest = [16, 15, -1, -1, 11, 10, -1, -1, -1, -1, 5, 4, -1, -1, -1, 1, 0]
#Energy_Int = Int_Energy(Seq, 2, 14, 3, 12)
#print(Energy_Int)

'''Seq = 'UGCCGGUGGCCAUAGUGGAGAGGUAAUACCCGUUCCCAUUCCGAACACGGAAGUCAAGCUCUCUUACGUCGAUGAUACUGGGUUCGUCCCGGGAAAGUAGAUAGCUGCCGGCUU'
Str_Nest = [-1, 111, 110, 109, 108, 107, 106, 105, 104, -1, -1, -1, -1, -1, 66, 65, 63, 62, 61, 60, 59, 58, -1, -1, -1, -1, -1, 53, 52, 49, 48, 47, 46, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 32, 31, 30, 29, -1, -1, 28, 27, -1, -1, -1, -1, 21, 20, 19, 18, 17, 16, -1, 15, 14, -1, 100, 99, -1, 97, 96, -1, -1, -1, -1, 91, 90, 89, 88, 87, -1, -1, -1, -1, -1, 81, 80, 79, 78, 77, -1, -1, -1, -1, 72, 71, -1, 69, 68, -1, -1, -1, 8, 7, 6, 5, 4, 3, 2, 1, -1, -1]
Stem_Nest = [[1, 111, 8], [14, 66, 2], [16, 63, 6], [27, 53, 2], [29, 49, 4], [68, 100, 2], [71, 97, 2], [77, 91, 5]]

Energy_Nest = Nest_Energy(Seq, Str_Nest, Stem_Nest)

print(Energy_Nest)'''