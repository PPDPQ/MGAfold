import random
import os
import math
import Real_Structure_Parallel_Two
import numpy as np
import matplotlib.pyplot as plt
import copy
import Stem_Energy
import pandas as pd

Path = 'Merge_Data_RePeat/Resut_Bracket/RNA_Profile_Result_16SRNA_Test.txt'

def Stem_Pool(Sequence):
    Length_Seq = len(Sequence)
    matrix = [[0] * Length_Seq for i in range(Length_Seq)]
    Stem = []
    i = 0
    while (i < Length_Seq):  # i代表行，j代表列, 只处理上三角
        j = i + 1
        while (j < Length_Seq):
            if ((Sequence[i] == 'A' and Sequence[j] == 'U') or (Sequence[i] == 'U' and Sequence[j] == 'A') or (
                            Sequence[i] == 'G' and Sequence[j] == 'C') or (Sequence[i] == 'C' and Sequence[j] == 'G')):
                matrix[i][j] = 1
            j += 1
        i += 1
    i = 0
    while (i < Length_Seq):  # i代表行，j代表列
        j = i + 1
        while (j < Length_Seq):
            if (matrix[i][j] == 1):
                Stem_Tem = []
                Stem_Tem.append(i)
                Stem_Tem.append(j)
                i1 = i
                j1 = j
                len_stem = 1
                matrix[i][j] = 0
                while (i1 < Length_Seq - 1 and j1 > 0 and matrix[i1 + 1][j1 - 1] == 1):
                    len_stem += 1
                    i1 += 1
                    j1 -= 1
                    matrix[i1][j1] = 0
                Stem_Tem.append(len_stem)
                Paired_Base_Length = (Stem_Tem[1] - Stem_Tem[2] + 1) - (Stem_Tem[0] + Stem_Tem[2] - 1) - 1
                if (len_stem >= 2 and Paired_Base_Length >= 3):
                    Stem.append(Stem_Tem)
            j += 1
        i += 1
    return Stem

# 创造条件茎区池, 终端必须是5’端和3‘端，中间可以有一侧是正确的，最后茎区进行延伸’,此时GU也可以考虑
def Stem_Pool_New(Sequence, Predict_Label):  # 收集的茎区是预测标签封口的茎区
    Length_Seq = len(Sequence)
    matrix = [[0] * Length_Seq for i in range(Length_Seq)]
    Stem = []
    i = 0
    while (i < Length_Seq):  # i代表行，j代表列, 只处理上三角
        j = i + 1
        while (j < Length_Seq):
            if ((Sequence[i] == 'A' and Sequence[j] == 'U') or (Sequence[i] == 'U' and Sequence[j] == 'A') or (
                            Sequence[i] == 'G' and Sequence[j] == 'C') or (Sequence[i] == 'C' and Sequence[j] == 'G')):
                matrix[i][j] = 1
            j += 1
        i += 1
    i = 0
    while (i < Length_Seq):  # i代表行，j代表列
        j = i + 1
        while (j < Length_Seq):
            if (matrix[i][j] == 1 and (Predict_Label[i] == '0' or Predict_Label[j] == '2')):  # 茎区起始
                Stem_Tem = []
                Stem_Tem.append(i)
                Stem_Tem.append(j)
                i1 = i
                j1 = j
                len_stem = 1
                matrix[i][j] = 0
                while (i1 < Length_Seq - 1 and j1 > 0 and matrix[i1 + 1][j1 - 1] == 1):
                    len_stem += 1
                    i1 += 1
                    j1 -= 1
                    matrix[i1][j1] = 0
                Start_Stem_End = i + len_stem - 1  # 5’端互补域最后一个碱基
                End_Stem_Start = j - len_stem + 1  # 3’端互补区第一个碱基
                # print(len_stem)
                # print(Start_Stem_End)
                # print(End_Stem_Start)
                while (Predict_Label[Start_Stem_End] != '0' and Predict_Label[End_Stem_Start] != '2'):  # 将茎区末尾非封口的碱基对删除
                    len_stem -= 1
                    Start_Stem_End -= 1
                    End_Stem_Start += 1
                Stem_Tem.append(len_stem)
                # Paired_Base_Length = (Stem_Tem[1] - Stem_Tem[2] + 1) - (Stem_Tem[0]+ Stem_Tem[2] - 1)-1
                if (len_stem >= 2):
                    Stem.append(Stem_Tem)
            j += 1
        i += 1
    return Stem

def Stem_Profile_Rate(Stem_Process, Profile_Label):
    Stem_Elite = []
    Stem_Process_List = []
    for Stem_Process_Num in range(len(Stem_Process)):
        Legngth_Stem_Base = Stem_Process[Stem_Process_Num][2] * 2
        Front_Start = Stem_Process[Stem_Process_Num][0]
        Rear_Start = Stem_Process[Stem_Process_Num][1] - Stem_Process[Stem_Process_Num][2] + 1
        Index_Profile_Stem = 0
        Profile_Stem_Base = 0
        while (Index_Profile_Stem < Stem_Process[Stem_Process_Num][2]):
            if (Profile_Label[Front_Start + Index_Profile_Stem] == '1'):
                Profile_Stem_Base += 1
            if (Profile_Label[Rear_Start + Index_Profile_Stem] == '1'):
                Profile_Stem_Base += 1
            Index_Profile_Stem += 1
        # Tem_Stem_List = []
        # Tem_Stem_List.append(Stem_Process[Stem_Process_Num])
        # Tem_Stem_List.append(Profile_Stem_Base/Legngth_Stem_Base)
        if (Profile_Stem_Base / Legngth_Stem_Base > 0.5):
            Stem_Process_List.append(Stem_Process[Stem_Process_Num])
        if (Profile_Stem_Base / Legngth_Stem_Base >= 1):
            Elite_Stem_Front_Start = Stem_Process[Stem_Process_Num][0]
            Elite_Stem_Front_End = Stem_Process[Stem_Process_Num][0] + Stem_Process[Stem_Process_Num][2] - 1
            Elite_Stem_Rear_End = Stem_Process[Stem_Process_Num][1]
            Elite_Stem_Rear_Start = Stem_Process[Stem_Process_Num][1] - Stem_Process[Stem_Process_Num][2] + 1
            if (Elite_Stem_Front_Start > 0 and Elite_Stem_Rear_End < len(Profile_Label) - 1):
                if (Profile_Label[Elite_Stem_Front_Start - 1] == '0' and Profile_Label[
                        Elite_Stem_Front_End + 1] == '0' and Profile_Label[Elite_Stem_Rear_Start - 1] == '0' and
                            Profile_Label[Elite_Stem_Rear_End + 1] == '0'):
                    Stem_Elite.append(Stem_Process[Stem_Process_Num])
            elif (Elite_Stem_Front_Start == 0):
                if (Profile_Label[Elite_Stem_Front_End + 1] == '0' and Profile_Label[
                        Elite_Stem_Rear_Start - 1] == '0' and Profile_Label[Elite_Stem_Rear_End + 1] == '0'):
                    Stem_Elite.append(Stem_Process[Stem_Process_Num])
            elif (Elite_Stem_Rear_End == len(Profile_Label) - 1):
                if (Profile_Label[Elite_Stem_Front_Start - 1] == '0' and Profile_Label[
                        Elite_Stem_Front_End + 1] == '0' and Profile_Label[Elite_Stem_Rear_Start - 1] == '0'):
                    Stem_Elite.append(Stem_Process[Stem_Process_Num])
    return Stem_Process_List, Stem_Elite

def Stem_Profile_Rate_Bracket(Stem_Process, Profile_Label):
    Stem_Process_List = []
    # Stem_Elite = []
    for Stem_Process_Num in range(len(Stem_Process)):
        Legngth_Stem_Base = Stem_Process[Stem_Process_Num][2]
        Front_Start = Stem_Process[Stem_Process_Num][0]
        Rear_Start = Stem_Process[Stem_Process_Num][1] - Stem_Process[Stem_Process_Num][2] + 1
        Index_Profile_Stem = 0
        Profile_Stem_Base_Front = 0
        Profile_Stem_Base_Rear = 0
        while (Index_Profile_Stem < Stem_Process[Stem_Process_Num][2]):
            if (Profile_Label[Front_Start + Index_Profile_Stem] == '0'):
                Profile_Stem_Base_Front += 1
            if (Profile_Label[Rear_Start + Index_Profile_Stem] == '2'):
                Profile_Stem_Base_Rear += 1
            Index_Profile_Stem += 1
        # Tem_Stem_List = []
        # Tem_Stem_List.append(Stem_Process[Stem_Process_Num])
        # Tem_Stem_List.append(Profile_Stem_Base/Legngth_Stem_Base)
        if (Profile_Stem_Base_Front / Legngth_Stem_Base >= 0.5 and Profile_Stem_Base_Rear / Legngth_Stem_Base >= 0.5):
            Stem_Process_List.append(Stem_Process[Stem_Process_Num])
            # if(Profile_Stem_Base_Front/Legngth_Stem_Base >= 0.5 and Profile_Stem_Base_Rear/Legngth_Stem_Base >= 0.5 and Stem_Process[Stem_Process_Num][2] > 4):
            # Stem_Elite.append(Stem_Process[Stem_Process_Num])
    return Stem_Process_List  # ,Stem_Elite

def Stem_Profile_Rate_Bracket_New(Stem_Process, Profile_Label):
    Stem_Process_List = []
    # Stem_Elite = []
    for Stem_Process_Num in range(len(Stem_Process)):
        Legngth_Stem_Base = Stem_Process[Stem_Process_Num][2]
        Front_Start = Stem_Process[Stem_Process_Num][0]
        Rear_Start = Stem_Process[Stem_Process_Num][1] - Stem_Process[Stem_Process_Num][2] + 1
        Index_Profile_Stem = 0
        Profile_Stem_Base_Front = 0
        Profile_Stem_Base_Rear = 0
        while (Index_Profile_Stem < Stem_Process[Stem_Process_Num][2]):
            if (Profile_Label[Front_Start + Index_Profile_Stem] == '0'):
                Profile_Stem_Base_Front += 1
            if (Profile_Label[Rear_Start + Index_Profile_Stem] == '2'):
                Profile_Stem_Base_Rear += 1
            Index_Profile_Stem += 1
        # Tem_Stem_List = []
        # Tem_Stem_List.append(Stem_Process[Stem_Process_Num])
        # Tem_Stem_List.append(Profile_Stem_Base/Legngth_Stem_Base)
        if (Profile_Stem_Base_Front / Legngth_Stem_Base >= 0.5 and Profile_Stem_Base_Rear / Legngth_Stem_Base >= 0.5):
            Stem_Process_List.append(Stem_Process[Stem_Process_Num])
            # if(Profile_Stem_Base_Front/Legngth_Stem_Base >= 0.5 and Profile_Stem_Base_Rear/Legngth_Stem_Base >= 0.5 and Stem_Process[Stem_Process_Num][2] > 4):
            # Stem_Elite.append(Stem_Process[Stem_Process_Num])
    return Stem_Process_List  # ,Stem_Elite

def Sample_Select_Stem(Sample_Stem):  # 选出无交叉的茎区组合
    Sample_Stem_Selected = []
    for number_sample_stem in range(len(Sample_Stem)):
        if (number_sample_stem == 0):
            Sample_Stem_Selected.append(Sample_Stem[number_sample_stem])
        else:
            flag = True
            for number_sample_stem_selected in range(len(Sample_Stem_Selected)):
                Current_Front_Start = Sample_Stem[number_sample_stem][0]
                Current_Front_End = Sample_Stem[number_sample_stem][0] + Sample_Stem[number_sample_stem][2] - 1
                Current_Rear_Start = Sample_Stem[number_sample_stem][1] - Sample_Stem[number_sample_stem][2] + 1
                Current_Rear_End = Sample_Stem[number_sample_stem][1]
                Compare_Front_Start = Sample_Stem_Selected[number_sample_stem_selected][0]
                Compare_Front_End = Sample_Stem_Selected[number_sample_stem_selected][0] + \
                                    Sample_Stem_Selected[number_sample_stem_selected][2] - 1
                Compare_Rear_Start = Sample_Stem_Selected[number_sample_stem_selected][1] - \
                                     Sample_Stem_Selected[number_sample_stem_selected][2] + 1
                Compare_Rear_End = Sample_Stem_Selected[number_sample_stem_selected][1]
                if (
                                    Compare_Front_Start > Current_Front_End and Compare_Front_End < Current_Rear_Start and Compare_Rear_Start > Current_Rear_End):
                    flag = False
                    break
                if (
                                    Current_Front_Start > Compare_Front_End and Current_Front_End < Compare_Rear_Start and Current_Rear_Start > Compare_Rear_End):
                    flag = False
                    break
                Current_Rear_Number = Current_Rear_Start
                while (Current_Rear_Number <= Current_Rear_End):
                    if (Current_Rear_Number >= Compare_Front_Start and Current_Rear_Number <= Compare_Front_End):
                        flag = False
                        break
                    if (Current_Rear_Number >= Compare_Rear_Start and Current_Rear_Number <= Compare_Rear_End):
                        flag = False
                        break
                    Current_Rear_Number += 1
                Current_Front_Number = Current_Front_Start
                while (Current_Front_Number <= Current_Front_End):
                    if (Current_Front_Number >= Compare_Front_Start and Current_Front_Number <= Compare_Front_End):
                        flag = False
                        break
                    if (Current_Front_Number >= Compare_Rear_Start and Current_Front_Number <= Compare_Rear_End):
                        flag = False
                        break
                    Current_Front_Number += 1
            if (flag):
                Sample_Stem_Selected.append(Sample_Stem[number_sample_stem])
    return Sample_Stem_Selected

def Create_Sample(Stem_Clean_Number, Sequence_Length):  # 创建个体
    Min_Stem_Number = int(Sequence_Length / 30)
    Max_Stem_Number = int(Sequence_Length / 11)
    # Stem_Index = list(range(0, len(Stem_Clean_Number))) #生成茎区所在下标
    # print(Stem_Index)
    Structure_Sample = []
    for i in range(10000):
        Stem_Number = (Min_Stem_Number + Max_Stem_Number) * 3
        # print(Stem_Number)
        Structure_Index = random.sample(Stem_Clean_Number, Stem_Number)
        # Structure_Tem = [Stem_Clean_Number[i_stem_number] for i_stem_number in Structure_Index]
        Structure_Sample.append(Structure_Index)
    return Structure_Sample

'''def Profile_Rate(Predict_Profile, Sample_Stem_Clean_Number, Stem_Clean): #计算预测结构中预测Profile所占用比例
    Sample_Stem = [Stem_Clean[stem_clean_Index] for stem_clean_Index in Sample_Stem_Clean_Number]
    Sample_NoRe_Profile = Sample_Select_Stem(Sample_Stem) #去除冗余茎区
    Sample_Profile = [0]*len(Predict_Profile)
    Profile_Base_Number = 0 # 统计结构中Profile预测为配对碱基的个数
    Structure_Paired_Base_Number = 0 #统计结构中配对碱基的个数
    for num_profile in range(len(Sample_NoRe_Profile)):
        Front_Start_Profile = Sample_NoRe_Profile[num_profile][0]
        Front_End_Profile = Sample_NoRe_Profile[num_profile][0] + Sample_NoRe_Profile[num_profile][2]-1
        Rear_Start_Profile = Sample_NoRe_Profile[num_profile][1] - Sample_NoRe_Profile[num_profile][2] + 1
        Rear_End_Profile = Sample_NoRe_Profile[num_profile][1]
        Structure_Paired_Base_Number += Sample_NoRe_Profile[num_profile][2]*2
        while(Front_Start_Profile <= Front_End_Profile):
            if(Predict_Profile[Front_Start_Profile] == "1"):
                Profile_Base_Number += 1
            Front_Start_Profile += 1
        while(Rear_Start_Profile <= Rear_End_Profile):
            if(Predict_Profile[Rear_Start_Profile] == "1"):
                Profile_Base_Number += 1
            Rear_Start_Profile += 1
    return Profile_Base_Number/Structure_Paired_Base_Number, Profile_Base_Number/len(Predict_Profile) #输出茎区组合预测配对占所有配对碱基的比例，以及占整体序列的比例
'''

# 计算预测结果中正确预测碱基的个数
def Profile_Rate(Predict_Profile, Sample_Stem_Clean_Number):  # , Stem_Clean): #计算预测结构中预测Profile所占用比例
    # 修改后的算法Sample_Stem_Clean_Number是去冗余的茎区组合 不是数字下标
    # Sample_Stem = [Stem_Clean[stem_clean_Index] for stem_clean_Index in Sample_Stem_Clean_Number]
    Sample_NoRe_Profile = Sample_Stem_Clean_Number  # Sample_Select_Stem(Sample_Stem) #去除冗余茎区
    Sample_Profile = [1] * len(Predict_Profile)
    Profile_True_Number = 0  # 预测结果与Profile相同的茎区
    for num_profile in range(len(Sample_NoRe_Profile)):
        Front_Start_Profile = Sample_NoRe_Profile[num_profile][0]
        Front_End_Profile = Sample_NoRe_Profile[num_profile][0] + Sample_NoRe_Profile[num_profile][2] - 1
        Rear_Start_Profile = Sample_NoRe_Profile[num_profile][1] - Sample_NoRe_Profile[num_profile][2] + 1
        Rear_End_Profile = Sample_NoRe_Profile[num_profile][1]
        while (Front_Start_Profile <= Front_End_Profile):
            Sample_Profile[Front_Start_Profile] = 0
            Front_Start_Profile += 1
        while (Rear_Start_Profile <= Rear_End_Profile):
            Sample_Profile[Rear_Start_Profile] = 2
            Rear_Start_Profile += 1
    for number_predict_sample in range(len(Predict_Profile)):
        if (int(Predict_Profile[number_predict_sample]) == Sample_Profile[number_predict_sample]):
            Profile_True_Number += 1
    return Profile_True_Number / len(Predict_Profile)  # 输出茎区组合预测配对占所有配对碱基的比例，以及占整体序列的比例

def Sample_Optimization(Sample_Number_Optimization, Predict_Profile_Optimization,Stem_Clean_Optimization):  # 利用预测的Profile优化个体
    # 将每个新创建的个体进行优化
    # Sample_Number_Optimization实数编码的单一个体样本
    # Predict_Profile_Optimization结构预测的Profile
    # Stem_Clean_Optimization清洗后的茎区池子
    Sample_Stem_Optimization = [Stem_Clean_Optimization[stem_clean_optimatization_Index] for
                                stem_clean_optimatization_Index in Sample_Number_Optimization]  # 获得初始个体的茎区
    Sample_NoRe_Profile = Sample_Select_Stem(Sample_Stem_Optimization)  # 去除冗余茎区-初始个体
    Protile_Rate_Opti = Profile_Rate(Predict_Profile_Optimization, Sample_NoRe_Profile)  # 记录当前的比率
    Sample_Stem_Opti_List = list(range(0, len(Sample_Stem_Optimization)))
    # print("#####")
    # print(Protile_Rate_Opti)
    # Opti_Exch_Stem_Number_List = [1, 1] # 存储交换长度
    # Totel_Rate = Total_Rate_Tem
    # if(len(Sample_Stem_Optimization) == 1):
    Sample_Number_Optimization_Tem = copy.deepcopy(Sample_Number_Optimization)
    for i_Optimization in range(200):
        # print(Protile_Rate_Opti)
        # print(Protile_Rate_Opti)
        # Opti_Exch_Stem_Number = random.sample(Opti_Exch_Stem_Number_List, 1) #交换长度
        Exch_Index = random.sample(Sample_Stem_Opti_List, 2)  # 交换起始位置,一次交换一个位置
        Mid_Number = Sample_Number_Optimization_Tem[Exch_Index[0]]
        Sample_Number_Optimization_Tem[Exch_Index[0]] = Sample_Number_Optimization_Tem[Exch_Index[1]]
        Sample_Number_Optimization_Tem[Exch_Index[1]] = Mid_Number
        Sample_Stem_Optimization_Tem = [Stem_Clean_Optimization[stem_clean_optimatization_Index_Tem] for
                                        stem_clean_optimatization_Index_Tem in
                                        Sample_Number_Optimization_Tem]  # 获得初始个体的茎区
        Sample_NoRe_Profile_Tem = Sample_Select_Stem(Sample_Stem_Optimization_Tem)  # 去除冗余茎区-初始个体
        # Sample_Number_Optimization_Tem[Exch_Index[0]:Exch_Index[0] + Opti_Exch_Stem_Number[0]], Sample_Number_Optimization_Tem[Exch_Index[1] : Exch_Index[1] + Opti_Exch_Stem_Number[0]] = Sample_Number_Optimization_Tem[Exch_Index[1] : Exch_Index[1] + Opti_Exch_Stem_Number[0]], Sample_Number_Optimization_Tem[Exch_Index[0]:Exch_Index[0] + Opti_Exch_Stem_Number[0]]
        Protile_Rate_Opti_Exch_Tem = Profile_Rate(Predict_Profile_Optimization, Sample_NoRe_Profile_Tem)  # 记录记录交换后的比率
        if (Protile_Rate_Opti_Exch_Tem > Protile_Rate_Opti):
            Protile_Rate_Opti = Protile_Rate_Opti_Exch_Tem
            Sample_Number_Optimization = copy.deepcopy(Sample_Number_Optimization_Tem)
    # print(Protile_Rate_Opti)
    # Sample_Stem_Optimization_Result = []
    # Sample_Stem_Optimization_Result.append(Sample_Stem_Optimization)
    # Sample_Stem_Optimization_Result.append(Totel_Rate)
    # print(Protile_Rate_Opti)
    return Sample_Number_Optimization  # Sample_Stem_Optimization_Result #返回优化后的个体

def Sample_Optimization_Group(Sample_Number_Group, Predict_Profile_Group, Stem_Clean_Group):  # 将群体的个体进行初步优化
    # 将群体个体调用单一个体优化函数，进而对群体个体进行优化
    Sample_Optimization_Result = []
    for group_optimization_number in range(len(Sample_Number_Group)):
        Sample_Optimization_Result_Tem = Sample_Optimization(Sample_Number_Group[group_optimization_number],
                                                             Predict_Profile_Group, Stem_Clean_Group)
        Sample_Optimization_Result.append(Sample_Optimization_Result_Tem)
    return Sample_Optimization_Result

def HFold_Command_Create(Sequence_Str, Sample_Stem):  # 制作HFold运行命令
    # print(Sample_Stem)
    Sequence_Length = len(Sequence_Str)
    # print(Sequence_Length)
    Contrain = ['.' for commond_num in range(Sequence_Length)]
    Contrain_Str = ""
    for num_command_stem in range(len(Sample_Stem)):
        Stem_Length_Index = 0
        while (Stem_Length_Index < Sample_Stem[num_command_stem][2]):
            Contrain[Sample_Stem[num_command_stem][0] + Stem_Length_Index] = '('
            Contrain[Sample_Stem[num_command_stem][1] - Stem_Length_Index] = ')'
            Stem_Length_Index += 1
    for ii in range(len(Contrain)):
        Contrain_Str += Contrain[ii]
    Command_HFold = './HFold --s "' + Sequence_Str
    Command_HFold = Command_HFold + '"'
    Command_HFold = Command_HFold + ' --r "'
    Command_HFold = Command_HFold + Contrain_Str
    Command_HFold = Command_HFold + '"'
    return Command_HFold

def Sim_Command_Create(Sequence_Str, Sample_Stem):  # 制作HFold运行命令
    # print(Sample_Stem)
    Sequence_Length = len(Sequence_Str)
    # print(Sequence_Length)
    Contrain = ['.' for commond_num in range(Sequence_Length)]
    Contrain_Str = ""
    for num_command_stem in range(len(Sample_Stem)):
        Stem_Length_Index = 0
        while (Stem_Length_Index < Sample_Stem[num_command_stem][2]):
            Contrain[Sample_Stem[num_command_stem][0] + Stem_Length_Index] = '('
            Contrain[Sample_Stem[num_command_stem][1] - Stem_Length_Index] = ')'
            Stem_Length_Index += 1
    for ii in range(len(Contrain)):
        Contrain_Str += Contrain[ii]
    Command_Sim = './simfold -s "' + Sequence_Str
    Command_Sim = Command_Sim + '"'
    Command_Sim = Command_Sim + ' -r "'
    Command_Sim = Command_Sim + Contrain_Str
    Command_Sim = Command_Sim + '"'
    return Command_Sim

def Stem_Sort(Stem, Sequence):
    Stem_Enery = []
    for i2 in range(len(Stem)):
        Enry = Stem_Energy.Energy_Stem(Stem[i2], Sequence)
        Stem_Tem = []
        Stem_Tem.append(Stem[i2])
        Stem_Tem.append(Enry)
        Stem_Enery.append(Stem_Tem)
    sorted_list = sorted(Stem_Enery, key=lambda x: x[1])
    return sorted_list

def PC_Value(Pcmax, Pcmin, Fitness_Mean, Fitness_Max, Fitness_Sample):  # 自适应遗传算法计算交叉概率
    if (Fitness_Sample < Fitness_Mean):
        Pc = Pcmax
    else:
        Pc = Pcmax - ((Pcmax - Pcmin) * (Fitness_Sample - Fitness_Mean)) / (Fitness_Max - Fitness_Mean)
    return Pc

def PM_Value(Pmmax, Pmmin, Fitness_Mean, Fitness_Max, Fitness_Sample):  # 自适应遗传算法计算机变异概率
    if (Fitness_Sample < Fitness_Mean):
        Pm = Pmmax
    else:
        Pm = Pmmax - ((Pmmax - Pmmin) * (Fitness_Sample - Fitness_Mean)) / (Fitness_Max - Fitness_Mean)
    return Pm
# 查找列表指定元素的索引
def index_of(Championship_Value, Crow_list):  #
    for Championship_Value_Index in range(0, len(Crow_list)):
        if (Crow_list[Championship_Value_Index] == Championship_Value):
            return Championship_Value_Index
    return -1

def Championship_Sort(Championship_Number_Index, Front_Championship_Sort, Rank_Championship_Sort,Crowing_Championship_Sort):
    # 对锦标赛团体中的个体进行排序：首先按照Rank排序，Rank值越小越优秀，当Rank值相同时，按照拥挤度值排序，拥挤度值越大越优秀
    # Championship_Number_Index 存放的是个体的下标, Front_Championship_Sort 帕累托值, Rank_Championship_Sort Rank值
    # Crowing_Championship_Sort 存放拥挤度值
    Championship_Number_Index_Sort = []
    for ch_nu in range(len(Championship_Number_Index)):
        Tem = []
        for cham_num in range(len(Championship_Number_Index[ch_nu])):
            Tem_cham = []
            Champion_Sample = Championship_Number_Index[ch_nu][cham_num]  # 获得个体
            Champion_Rank = Rank_Championship_Sort[Champion_Sample]  # 获得个体的Rank值
            Tem_cham.append(Champion_Sample)  # 方个体
            Tem_cham.append(Champion_Rank)  # 方Rank值
            cham_sam_index = index_of(Champion_Sample, Front_Championship_Sort[Champion_Rank])  # 获得个体在拥挤值中的下标
            Tem_cham.append(0 - Crowing_Championship_Sort[Champion_Rank][cham_sam_index])  # 存放拥挤度的相反数便于从小到大进行排序
            Tem.append(Tem_cham)
        Tem = sorted(Tem, key=lambda x: (x[1], x[2]))
        Tem = [x[0] for x in Tem]
        Championship_Number_Index_Sort.append(Tem)
    return Championship_Number_Index_Sort  # 对锦标赛团体中的个体进行排序

def Championship_Sample_Function(Sample_Fitness, Championship_Number,Championship_Length):  # 创建锦标赛团体, Sample_Fitness带适应度的个体
    # Championship_Numbr 锦标赛团体个数, Championship_Length锦标赛团体大小
    # 返回的结果格式是个体在种群中的下标
    # 遗传算法的选择部分
    Sample_Fitness_Index = list(range(0, len(Sample_Fitness)))  # 生成候选个体下标
    Championship_Sample_List = []
    for chamption_index in range(Championship_Number):
        Championship_Sample = random.sample(Sample_Fitness_Index, Championship_Length)
        Championship_Sample_List.append(Championship_Sample)
    return Championship_Sample_List

def Cross_Sample(Sample_Cross, Championship_Sample_Corss):  # Sample_Cross样本个体, Championship_Sample_List锦标赛团体
    # 遗传算法的交叉部分
    Father_First = copy.deepcopy(Sample_Cross[Championship_Sample_Corss[0]])  # 深度拷贝锦标赛团体的第一个个体作为第一个父样本
    Father_Secondary = copy.deepcopy(Sample_Cross[Championship_Sample_Corss[1]])  # 深度拷贝锦标赛团体的第二个个体作为第二个父样本
    Sample_Length = len(Father_First)
    Fc_Value = 1  # 固定交叉概率
    Fc_Value_Random = random.random()
    if (Fc_Value_Random < Fc_Value):  # 单点交叉
        Pot_Cross = random.randint(0, Sample_Length - 1)  # 单点交叉位点
        Children = Father_First[0:Pot_Cross] + Father_Secondary[Pot_Cross: Sample_Length]
    else:
        Children = Father_First
    return Children

def Mutation_Sample(Sample_Mutation, Championship_Sample_Mutation,Clean_Stem_Number_Mutation):  # Sample_Mutation只包含茎区样本的个体
    # Championship_Sample_Mutation 存放个体下标的锦标赛团体
    # 遗传算法的突变部分
    Children_Variation = copy.deepcopy(Sample_Mutation[Championship_Sample_Mutation[0]])  # 对变异父样本进行深度拷贝
    Fm_Value = 1
    Fm_Value_Random = random.random()
    Sample_Variation_Length = len(Children_Variation)
    if (Fm_Value_Random < Fm_Value):
        Variation_Type = [1, 2, 3]  # 1代表位点变异, 2代表位两点交互,3代表一段序列翻转
        Variation_Type_Number = random.sample(Variation_Type, 1)
        if (Variation_Type_Number[0] == 1):  # 单点更新
            Pot_Variation = random.randint(0, Sample_Variation_Length - 1)
            Update_Point = random.randint(0, Clean_Stem_Number_Mutation - 1)  # Children_Variation[Pot_Variation])
            Children_Variation[Pot_Variation] = Update_Point
            Children = Children_Variation
        elif (Variation_Type_Number[0] == 2):  # 两点兑换位置
            Exchange_Pot_Variation_First = random.randint(0, Sample_Variation_Length - 1)
            Exchange_Pot_Variation_Secondary = random.randint(0, Sample_Variation_Length - 1)
            Mid_Value = Children_Variation[Exchange_Pot_Variation_First]
            Children_Variation[Exchange_Pot_Variation_First] = Children_Variation[Exchange_Pot_Variation_Secondary]
            Children_Variation[Exchange_Pot_Variation_Secondary] = Mid_Value
            Children = Children_Variation
        else:
            Reverse_Pot_Variation_First = random.randint(0, Sample_Variation_Length - 1)
            Reverse_Pot_Variation_Second = random.randint(0, Sample_Variation_Length - 1)
            if (Reverse_Pot_Variation_First > Reverse_Pot_Variation_Second):
                Mid_Temp = Reverse_Pot_Variation_First
                Reverse_Pot_Variation_First = Reverse_Pot_Variation_Second
                Reverse_Pot_Variation_Second = Mid_Temp
            Split_Children_Variation = Children_Variation[Reverse_Pot_Variation_First: Reverse_Pot_Variation_Second]
            Split_Children_Variation.reverse()
            Children = Children_Variation[
                       0:Reverse_Pot_Variation_First] + Split_Children_Variation + Children_Variation[
                                                                                   Reverse_Pot_Variation_Second:]
    else:
        Children = Children_Variation
    return Children

def Sample_Evolution(Structure_Sample_Fitness, Fitness_Max, Fitness_Mean, Predict_Profile, Stem_Clean,Generation_Number):  # 物种进化
    # Structure_Sample_Fitness是带适应值的物种个体, Stem_Clean清洗后的茎区
    Structure_Sample_Fitness_Next_Generation = copy.deepcopy(Structure_Sample_Fitness[0:10])  # 保留十个精英
    Championship_Sample_List = Championship_Sample_Function(Structure_Sample_Fitness,
                                                            len(Structure_Sample_Fitness) - 10,
                                                            4)  # 生成整体减10个锦标赛团体,每个团体均进行排序,每个团体包含四个个体
    Fc_Generation_Sample = len(Structure_Sample_Fitness) * 0.8 - 10  # 交叉产生的新个体数目
    Pcmax = 0.9  # 初始化交叉最大概率
    Pcmin = 0.1  # 初始化交叉最小概率
    Pmmax = 0.9  # 初始化变异最大概率
    Pmmin = 0.1  # 初始化变异最小概率
    Championship_Index = 0  # 团体下标
    Sample_Length = len(Championship_Sample_List[0][0][0])
    Structure_Sample_Fitness_Child = []
    # for Elite_Number in range(len(Structure_Sample_Fitness_Next_Generation)): #保存精英个体至孩子列表
    #    Structure_Sample_Fitness_Child.append(Structure_Sample_Fitness_Next_Generation[Elite_Number])
    while (Championship_Index < Fc_Generation_Sample):
        Father_First = copy.deepcopy(Championship_Sample_List[Championship_Index][0][0])  # 对父样本进行深度复制
        Father_Secondary = copy.deepcopy(Championship_Sample_List[Championship_Index][1][0])  # 对父样本进行深度复制
        Fitness_Father_First = Championship_Sample_List[Championship_Index][0][1]
        if (Generation_Number < 1000):
            Fc_Value = Pcmax
        else:
            Fc_Value = PC_Value(Pcmax, Pcmin, Fitness_Mean, Fitness_Max, Fitness_Father_First)
        Fc_Value_Random = random.random()
        if (Fc_Value_Random < Fc_Value):
            Pot_Cross = random.randint(0, Sample_Length - 1)  # 单点交叉位点
            Children = Father_First[0:Pot_Cross] + Father_Secondary[Pot_Cross: Sample_Length]
        else:
            Children = Father_First
        Children_Fitness = Profile_Rate(Predict_Profile, Children, Stem_Clean)
        Tem_Children = []
        Tem_Children.append(Children)
        Tem_Children.append(Children_Fitness)
        Structure_Sample_Fitness_Next_Generation.append(Tem_Children)
        Championship_Index += 1
    while (Championship_Index < len(Championship_Sample_List)):
        Children_Variation = copy.deepcopy(Championship_Sample_List[Championship_Index][0][0])  # 对变异父样本进行深度拷贝
        Fitness_Father_First = Championship_Sample_List[Championship_Index][0][1]
        if (Generation_Number < 1000):
            Fm_Value = Pcmax
        else:
            Fm_Value = PM_Value(Pmmax, Pmmin, Fitness_Mean, Fitness_Max, Fitness_Father_First)
        Fm_Value_Random = random.random()
        Sample_Variation_Length = len(Children_Variation)
        if (Fm_Value_Random < Fm_Value):
            Variation_Type = [1, 2, 3]  # 1代表位点变异, 2代表位两点交互,3代表一段序列翻转
            Variation_Type_Number = random.sample(Variation_Type, 1)
            if (Variation_Type_Number[0] == 1):  # 单点更新
                Pot_Variation = random.randint(0, Sample_Variation_Length - 1)
                Update_Point = random.randint(0, Children_Variation[Pot_Variation])
                Children_Variation[Pot_Variation] = Update_Point
                Children = Children_Variation
            elif (Variation_Type_Number[0] == 2):  # 两点兑换位置
                Exchange_Pot_Variation_First = random.randint(0, Sample_Variation_Length - 1)
                Exchange_Pot_Variation_Secondary = random.randint(0, Sample_Variation_Length - 1)
                Mid_Value = Children_Variation[Exchange_Pot_Variation_First]
                Children_Variation[Exchange_Pot_Variation_First] = Children_Variation[Exchange_Pot_Variation_Secondary]
                Children_Variation[Exchange_Pot_Variation_Secondary] = Mid_Value
                Children = Children_Variation
            else:
                Reverse_Pot_Variation_First = random.randint(0, Sample_Variation_Length - 1)
                Reverse_Pot_Variation_Second = random.randint(0, Sample_Variation_Length - 1)
                if (Reverse_Pot_Variation_First > Reverse_Pot_Variation_Second):
                    Mid_Temp = Reverse_Pot_Variation_First
                    Reverse_Pot_Variation_First = Reverse_Pot_Variation_Second
                    Reverse_Pot_Variation_Second = Mid_Temp
                Split_Children_Variation = Children_Variation[Reverse_Pot_Variation_First: Reverse_Pot_Variation_Second]
                Split_Children_Variation.reverse()
                Children = Children_Variation[
                           0:Reverse_Pot_Variation_First] + Split_Children_Variation + Children_Variation[
                                                                                       Reverse_Pot_Variation_Second:]
        else:
            Children = Children_Variation
        Children_Fitness = Profile_Rate(Predict_Profile, Children, Stem_Clean)
        Tem_Children = []
        Tem_Children.append(Children)
        Tem_Children.append(Children_Fitness)
        Structure_Sample_Fitness_Next_Generation.append(Tem_Children)
        Championship_Index += 1
    Structure_Sample_Fitness_Next_Generation = sorted(Structure_Sample_Fitness_Next_Generation, key=lambda x: x[1],
                                                      reverse=True)  # 按照适应度由大到小对新一代个体进行排序
    return Structure_Sample_Fitness_Next_Generation

def GA_Sample_Evlution(Sample_GA, Championtion_Sort, Clean_Stem_Number_GA):  # Sample_GA样本个体
    # Championtion_Sort排过序的锦标赛团体
    # 生成下一代个体
    Sample_Next_Generation = []
    All_Sample = len(Championtion_Sort)
    Index_GA = 0
    while (Index_GA < int(0.6 * All_Sample)):
        Children_Tem = Cross_Sample(Sample_GA, Championtion_Sort[Index_GA])
        Sample_Next_Generation.append(Children_Tem)
        Index_GA += 1
    while (Index_GA < All_Sample):
        Children_Tem = Mutation_Sample(Sample_GA, Championtion_Sort[Index_GA], Clean_Stem_Number_GA)
        Sample_Next_Generation.append(Children_Tem)
        Index_GA += 1
    return Sample_Next_Generation

def Profile_Fitness_Value(Sample_Profile_Fitness, Predict_Label_Profile_Fitness,Stem_Clean_Profile_Fitness):  # 计算Profile的fitness值，Sample_Profile_Fitness为实数编码的个体样本
    # Stem_Clean存放实数编码对应的茎区,
    Structure_Sample_Profile_Fitness = []  # 原始下标样本Profile的值
    for iv in range(len(Sample_Profile_Fitness)):
        # Tem_Fitness = []
        Profile_Rate_Sample = Profile_Rate(Predict_Label_Profile_Fitness, Sample_Profile_Fitness[iv],
                                           Stem_Clean_Profile_Fitness)
        # Tem_Fitness.append(Structure_Sample[iv])
        # Tem_Fitness.append(Profile_Rate_Sample)
        Structure_Sample_Profile_Fitness.append(Profile_Rate_Sample)
    return Structure_Sample_Profile_Fitness

def Stem_to_Structure(Sample_Stem_NoRe,Sequence):  # 将茎区组合转化为结构列表, Structure = [-1, -1, -1, -1, -1, -1, -1, -1, -1, 191, 190, 189, -1, -1, 71, 70, -1, -1, -1, -1, -1, -1, 59, 58, 57, 56, 55, 54, -1, -1, -1, -1, 257, 256, 255, 254, 253, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 27, 26, 25, 24, 23, 22, 67, 66, 65, -1, -1, 62, 61, 60, -1, -1, 15, 14, -1, -1, -1, -1, -1, -1, -1, 159, 158, 157, 156, 155, 154, 153, 152, 151, 150, 149, 148, 147, 146, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 238, 237, 236, 235, 234, 233, 232, 231, 230, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 92, 91, 90, 89, 88, 87, 86, 85, 84, 83, 82, 81, 80, 79, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 219, 218, 217, 216, -1, -1, -1, -1, -1, -1, -1, 11, 10, 9, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 181, 180, 179, 178, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 112, 111, 110, 109, 108, 107, 106, 105, 104, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 36, 35, 34, 33, 32, -1, -1, -1, -1]
    Sample_Structure = [-1] * len(Sequence)
    for stem_structure_num in range(len(Sample_Stem_NoRe)):
        stem_start = Sample_Stem_NoRe[stem_structure_num][0]  # 茎区起始
        sten_end = Sample_Stem_NoRe[stem_structure_num][1]  # 茎区终止
        Index_Length = 0
        while (Index_Length < Sample_Stem_NoRe[stem_structure_num][2]):
            Sample_Structure[stem_start + Index_Length] = sten_end - Index_Length
            Sample_Structure[sten_end - Index_Length] = stem_start + Index_Length
            Index_Length += 1
    return Sample_Structure

def Energy_Fitness_Value(Sample_Energy_Fitness, Stem_Clean_Value_Fitness, Sequence_Value_Fitness):
    # Sample_Energy_Fitness 用来计算能量Fitness的样本, Stem_Clean_Value_Fitness所有清洗过的茎区,Sequence_Value_FitnessRNA序列
    # Sequence_Value_Fitness 需要字符串类型的RNA序列
    Structure_Sample_Energy_Fitness = []  # 用来存放能量Fitness
    # print(len(Sample_Energy_Fitness))
    for ie in range(len(Sample_Energy_Fitness)):
        Sample_Energy_Stem = [Stem_Clean_Value_Fitness[stem_clean_Index_Energy] for stem_clean_Index_Energy in
                              Sample_Energy_Fitness[ie]]
        Sample_Energy_Stem_NoRe = Sample_Select_Stem(Sample_Energy_Stem)  # 去除冗余茎区
        Sample_Structure = Stem_to_Structure(Sample_Energy_Stem_NoRe, Sequence)
        Energy = Stem_Energy.Nest_Energy(Sequence_Value_Fitness, Sample_Structure, Sample_Energy_Stem_NoRe)
        Structure_Sample_Energy_Fitness.append(0 - Energy)
    return Structure_Sample_Energy_Fitness

def Fitness_Value(Sample_Fitness, Stem_Clean_Fitness, Sequence_Fitness, Predict_Label_Profile_Fitness):
    # 计算样本的Profile和Energy的Fitness
    Structure_Sample_Energy_Fitness = []
    Structure_Sample_Profile_Fitness = []  # 原始下标样本Profile的值

    for ie in range(len(Sample_Fitness)):
        # print(Sample_Fitness[ie])
        Sample_Stem = [Stem_Clean_Fitness[stem_clean_Index_Fitness] for stem_clean_Index_Fitness in Sample_Fitness[ie]]
        Sample_Stem_NoRe = Sample_Select_Stem(Sample_Stem)  # 去除冗余茎区
        # Sample_Stem_NoRe = Sample_Stem_Extend(Sample_Stem_NoRe, Sequence_Fitness)
        Sample_Stem_Extend(Sample_Stem_NoRe, Sequence_Fitness)
        Profile_Fitness = Profile_Rate(Predict_Label_Profile_Fitness, Sample_Stem_NoRe)
        Sample_Structure = Stem_to_Structure(Sample_Stem_NoRe, Sequence)
        Energy = Stem_Energy.Nest_Energy(Sequence_Fitness, Sample_Structure, Sample_Stem_NoRe)
        Structure_Sample_Energy_Fitness.append(0 - Energy)  # 存放能量Fitness
        Structure_Sample_Profile_Fitness.append(Profile_Fitness)  # 存放Profile_Fitness
    return Structure_Sample_Profile_Fitness, Structure_Sample_Energy_Fitness

def Pareto_Function(Profile_Fitness_Pareto, Energy_Fitness_Pareto):
    Front = []  # 用来存放每一层Pareto的解
    Rank = [-1 for i in range(0, len(Profile_Fitness_Pareto))]  # 存放每一个个体在那一层Pareto解
    Np = [0 for i in range(0, len(Profile_Fitness_Pareto))]  # 存放每个个体被支配的个体数
    Sp = [[] for i in range(0, len(Profile_Fitness_Pareto))]  # 存放支配那些个体
    Front_Tem = []
    for Pareto_Num in range(len(Profile_Fitness_Pareto)):
        for Pareto_Num_Q in range(len(Profile_Fitness_Pareto)):
            if ((Profile_Fitness_Pareto[Pareto_Num] > Profile_Fitness_Pareto[Pareto_Num_Q] and Energy_Fitness_Pareto[
                Pareto_Num] > Energy_Fitness_Pareto[Pareto_Num_Q]) or
                    (Profile_Fitness_Pareto[Pareto_Num] >= Profile_Fitness_Pareto[Pareto_Num_Q] and
                             Energy_Fitness_Pareto[Pareto_Num] > Energy_Fitness_Pareto[Pareto_Num_Q]) or
                    (Profile_Fitness_Pareto[Pareto_Num] > Profile_Fitness_Pareto[Pareto_Num_Q] and
                             Energy_Fitness_Pareto[Pareto_Num] >= Energy_Fitness_Pareto[Pareto_Num_Q])):
                Sp[Pareto_Num].append(Pareto_Num_Q)
            elif ((Profile_Fitness_Pareto[Pareto_Num] < Profile_Fitness_Pareto[Pareto_Num_Q] and Energy_Fitness_Pareto[
                Pareto_Num] < Energy_Fitness_Pareto[Pareto_Num_Q]) or
                      (Profile_Fitness_Pareto[Pareto_Num] <= Profile_Fitness_Pareto[Pareto_Num_Q] and
                               Energy_Fitness_Pareto[Pareto_Num] < Energy_Fitness_Pareto[Pareto_Num_Q]) or
                      (Profile_Fitness_Pareto[Pareto_Num] < Profile_Fitness_Pareto[Pareto_Num_Q] and
                               Energy_Fitness_Pareto[Pareto_Num] <= Energy_Fitness_Pareto[Pareto_Num_Q])):
                Np[Pareto_Num] = Np[Pareto_Num] + 1
        if (Np[Pareto_Num] == 0):  # 获得第一层Pareto解
            Rank[Pareto_Num] = 0  # 初始化为第一层
            Front_Tem.append(Pareto_Num)
    Front.append(Front_Tem)  # 将第一层Pareto解放在Front前沿面里面
    i_pareto = 0
    All_Pareta_Sample = 0
    while (i_pareto < len(Front)):
        All_Pareta_Sample += len(Front[i_pareto])
        Front_Next_Level = []
        for pareto_front in Front[i_pareto]:
            for pareto_q in Sp[pareto_front]:
                Np[pareto_q] = Np[pareto_q] - 1
                if (Np[pareto_q] == 0):
                    Rank[pareto_q] = i_pareto + 1
                    Front_Next_Level.append(pareto_q)
        if (len(Front_Next_Level) != 0):
            Front.append(Front_Next_Level)
        i_pareto += 1
    return Front, Rank

def crowding_distance(Profile_Fitness, Energy_Fitness, Front_One_Level):
    # 计算某一层Pareto解的拥挤度
    Distance = [0 for i in range(0, len(Front_One_Level))]  # 存放每一个位置的Distance, 相对于原始的Front坐标不变
    Profile_Fitness_Level = [Profile_Fitness[Pro_Level] for Pro_Level in Front_One_Level]  # 取出当前帕累托解的所有Profile_Fitness
    Energy_Fitness_Level = [Energy_Fitness[Eng_Level] for Eng_Level in Front_One_Level]  # 取出当前帕累托解的所有Energy_Fitness
    Profile_Fitness_Level_Index = []  # 将原始的Front下标放在Profile_Fitness后面
    Energy_Fitness_Level_Index = []  # 将原始的Front下标放在Energy_Fitness后面
    for Front_One_Level_Num in range(len(Front_One_Level)):  # 将下标与Fitness值合并
        Profile_Fitness_Level_Index_Tem = []
        Energy_Fitness_Level_Index_Tem = []
        Profile_Fitness_Level_Index_Tem.append(Front_One_Level_Num)  # 放下标
        Profile_Fitness_Level_Index_Tem.append(Profile_Fitness_Level[Front_One_Level_Num])  # 放Profile_Fitness值

        Energy_Fitness_Level_Index_Tem.append(Front_One_Level_Num)  # 放下标
        Energy_Fitness_Level_Index_Tem.append(Energy_Fitness_Level[Front_One_Level_Num])  # 放Profile_Fitness值
        Profile_Fitness_Level_Index.append(Profile_Fitness_Level_Index_Tem)
        Energy_Fitness_Level_Index.append(Energy_Fitness_Level_Index_Tem)
    # 对每一个Fitness进行排序, 便于计算单一Fitness的拥挤值
    Profile_Fitness_Level_Index = sorted(Profile_Fitness_Level_Index, key=lambda x: x[1])
    Energy_Fitness_Level_Index = sorted(Energy_Fitness_Level_Index, key=lambda x: x[1])
    # 初始化单一Fitness值的距离列表
    Distance_Profile = [0 for i in range(0, len(Front_One_Level))]
    Distance_Energy = [0 for i in range(0, len(Front_One_Level))]
    # 初始化首尾个体的距离值, 初始化值为1000
    Distance_Profile[0] = 5000
    Distance_Profile[-1] = 1000
    Distance_Energy[0] = 5000
    Distance_Energy[-1] = 1000
    # 计算单一Fitness的拥挤值
    Dis_Index = 1
    while (Dis_Index < len(Distance_Profile) - 1):
        Distance_Profile[Dis_Index] = Profile_Fitness_Level_Index[Dis_Index + 1][1] - \
                                      Profile_Fitness_Level_Index[Dis_Index - 1][1]
        Distance_Energy[Dis_Index] = Energy_Fitness_Level_Index[Dis_Index + 1][1] - \
                                     Energy_Fitness_Level_Index[Dis_Index - 1][1]
        Dis_Index += 1
    # 将总的距离值放在列表里，相对下标不变
    for Dis_All in range(len(Distance_Profile)):
        Distance[Profile_Fitness_Level_Index[Dis_All][0]] += Distance_Profile[Dis_All]
        Distance[Energy_Fitness_Level_Index[Dis_All][0]] += Distance_Energy[Dis_All]

    return Distance

def Evolution_Sample_Select(Front_RNA_Evolution_Select, Crowding_Sample_RNA_Evolution_Select,Structure_Sample_RNA_Evolution_Select,Structure_Sample_Profile_Fitness_RNA_Evolution_Select,Structure_Sample_Energy_Fitness_RNA_Evolution_Select):  # 父子代合并中挑选出优秀的个体
    # 当父子代合并个体超过预定数目时从帕累托解中筛选出优秀个体
    # Front_RNA_Evolution_Select父子合并帕累托解
    # Crowding_Sample_RNA_Evolution_Select父子合并拥挤度值
    # Structure_Sample_RNA_Evolution_Select 父子合并个体
    # Structure_Sample_Profile_Fitness_RNA_Evolution_Select 父子合并Profile适应度值
    # Structure_Sample_Energy_Fitness_RNA_Evolution_Select 父子合并Energy适应度值
    Selected_Sample = []  # 挑选个体的容器
    Selected_Profile_Fitness = []  # 挑选Profile适应度值的容器
    Selected_Energy_Fitness = []  # 挑选Energy适应度值的容器
    for sample_select_num in range(len(Front_RNA_Evolution_Select)):  # sample_select_num相当于Rank值
        if (len(Selected_Sample) >= 1000):  # 当挑选的个体大于等于1000时直接结束
            break
        if (len(Selected_Sample) + len(Front_RNA_Evolution_Select[sample_select_num]) <= 1000):  # 将该层帕累托解全部放入新的个体中
            for select_number in range(len(Front_RNA_Evolution_Select[sample_select_num])):
                Selected_Sample.append(
                    Structure_Sample_RNA_Evolution_Select[Front_RNA_Evolution_Select[sample_select_num][select_number]])
                Selected_Profile_Fitness.append(Structure_Sample_Profile_Fitness_RNA_Evolution_Select[
                                                    Front_RNA_Evolution_Select[sample_select_num][select_number]])
                Selected_Energy_Fitness.append(Structure_Sample_Energy_Fitness_RNA_Evolution_Select[
                                                   Front_RNA_Evolution_Select[sample_select_num][select_number]])
        else:
            Crow_Select = []  # 将拥挤值的相反数与个体下标合并排序
            for crow_select_num in range(len(Crowding_Sample_RNA_Evolution_Select[sample_select_num])):
                Crow_Select_Tem = []
                Crow_Select_Tem.append(Front_RNA_Evolution_Select[sample_select_num][crow_select_num])
                Crow_Select_Tem.append(Crowding_Sample_RNA_Evolution_Select[sample_select_num][crow_select_num])
                Crow_Select.append(Crow_Select_Tem)
            Crow_Select = sorted(Crow_Select, key=lambda x: x[1], reverse=True)
            Index_Selected_Crow = 0
            while (len(Selected_Sample) < 1000):
                Selected_Sample.append(Structure_Sample_RNA_Evolution_Select[Crow_Select[Index_Selected_Crow][0]])
                Selected_Profile_Fitness.append(
                    Structure_Sample_Profile_Fitness_RNA_Evolution_Select[Crow_Select[Index_Selected_Crow][0]])
                Selected_Energy_Fitness.append(
                    Structure_Sample_Energy_Fitness_RNA_Evolution_Select[Crow_Select[Index_Selected_Crow][0]])
                Index_Selected_Crow += 1
    return Selected_Sample, Selected_Profile_Fitness, Selected_Energy_Fitness

def RNA_Secondary_Structure_Evolution(Stem_Clean_RNA_Evolution, Sequence_Str_RNA_Evolution,Predict_Label_RNA_Evolution):  # 整体进化过程
    Stem_Clean_Number_Coding_RNA_Evolution = list(range(0, len(Stem_Clean_RNA_Evolution)))  # 获得茎区实数编码
    Generation_Number = 1
    Structure_Sample_RNA_Evolution = Create_Sample(Stem_Clean_Number_Coding_RNA_Evolution,len(Sequence_Str_RNA_Evolution))  # 实数编码个体
    # Structure_Sample_RNA_Evolution = Sample_Optimization_Group(Structure_Sample_RNA_Evolution, Predict_Label_RNA_Evolution, Stem_Clean_RNA_Evolution) # 初始化个体优化
    Structure_Sample_Profile_Fitness_RNA_Evolution, Structure_Sample_Energy_Fitness_RNA_Evolution = Fitness_Value(Structure_Sample_RNA_Evolution, Stem_Clean_RNA_Evolution, Sequence_Str_RNA_Evolution,Predict_Label_RNA_Evolution)
    Result_Evolution = []
    # print(len(Structure_Sample_RNA_Evolution))
    # print(Structure_Sample_RNA_Evolution[0])
    Generation_Num = 3000  # 进化总代数
    Number_Generation_Unchange = 1
    Mark_Profile_Fitness = -1  #
    Mark_Energy_Fitness = -1
    while (Generation_Number < Generation_Num):
        # print("^%$#@%&(&")
        #print(Generation_Number)
        Front_RNA_Evolution, Rank_RNA_Evolution = Pareto_Function(Structure_Sample_Profile_Fitness_RNA_Evolution,Structure_Sample_Energy_Fitness_RNA_Evolution)
        # print("@@")
        # print(len(Front_RNA_Evolution[0]))
        Fitness_Max_Energy = np.max(Structure_Sample_Energy_Fitness_RNA_Evolution)  # 计算机适应度最大值
        Fitness_Max_Profile = np.max(Structure_Sample_Profile_Fitness_RNA_Evolution)  # 计算机适应度最大值
        if (Generation_Number == 1):
            Mark_Profile_Fitness = Fitness_Max_Profile
            Mark_Energy_Fitness = Fitness_Max_Energy
        else:
            if (Fitness_Max_Energy != Mark_Energy_Fitness or Fitness_Max_Profile != Mark_Profile_Fitness):
                Mark_Profile_Fitness = Fitness_Max_Profile
                Mark_Energy_Fitness = Fitness_Max_Energy
                Number_Generation_Unchange = 1
            else:
                Number_Generation_Unchange += 1

        if (Generation_Number % 100 == 0):
            print(Generation_Number)
            print("*********Energy Fitness**********")
            Fitness_Mean_Energy = np.mean(Structure_Sample_Energy_Fitness_RNA_Evolution)  # 计算适应度平均值

            Fitness_Min_Energy = np.min(Structure_Sample_Energy_Fitness_RNA_Evolution)  # 计算适应度最小值
            print(Fitness_Mean_Energy)
            print(Fitness_Max_Energy)
            print(Fitness_Min_Energy)
            print("*********Profile Fitness**********")
            Fitness_Mean_Profile = np.mean(Structure_Sample_Profile_Fitness_RNA_Evolution)  # 计算适应度平均值

            Fitness_Min_Profile = np.min(Structure_Sample_Profile_Fitness_RNA_Evolution)  # 计算适应度最小值
            print(Fitness_Mean_Profile)
            print(Fitness_Max_Profile)
            print(Fitness_Min_Profile)
        Crowding_Sample_RNA_Evolution = []  # 存储每一层帕累托解的拥挤值
        for Evolution_Num in range(len(Front_RNA_Evolution)):  # 获得拥挤值
            Distance = crowding_distance(Structure_Sample_Profile_Fitness_RNA_Evolution,Structure_Sample_Energy_Fitness_RNA_Evolution,Front_RNA_Evolution[Evolution_Num])
            Crowding_Sample_RNA_Evolution.append(Distance)
        Championship_Number_Index_RNA_Evolution = Championship_Sample_Function(Structure_Sample_RNA_Evolution, 1000,4)  # 获得一千个锦标赛团体, 团体大小为2
        Championship_Number_Index_Sort_RNA_Evolution = Championship_Sort(Championship_Number_Index_RNA_Evolution,Front_RNA_Evolution, Rank_RNA_Evolution,Crowding_Sample_RNA_Evolution)
        Sample_Next_Generation = GA_Sample_Evlution(Structure_Sample_RNA_Evolution,Championship_Number_Index_Sort_RNA_Evolution,len(Stem_Clean_RNA_Evolution))
        Structure_Sample_Profile_Fitness_Next, Structure_Sample_Energy_Fitness_Next = Fitness_Value(Sample_Next_Generation, Stem_Clean_RNA_Evolution, Sequence_Str_RNA_Evolution, Predict_Label_RNA_Evolution)
        if (len(Front_RNA_Evolution[0]) < 100):
            #Father_Sample_Elite = [Structure_Sample_RNA_Evolution[elite_num] for elite_num in Front_RNA_Evolution[0]]
            Crow_Select_Evolution = []  # 将拥挤值与个体下标合并排序
            for crow_select_evolution_num in range(len(Front_RNA_Evolution[0])):
                Crow_Select_Evolution_Tem = []
                Crow_Select_Evolution_Tem.append(Front_RNA_Evolution[0][crow_select_evolution_num])
                Crow_Select_Evolution_Tem.append(Crowding_Sample_RNA_Evolution[0][crow_select_evolution_num])
                Crow_Select_Evolution.append(Crow_Select_Evolution_Tem)
            Crow_Select_Evolution = sorted(Crow_Select_Evolution, key=lambda x: x[1], reverse=True)
            Crow_Select_Sample = [x[0] for x in Crow_Select_Evolution]
            Crow_Select_Sample = Crow_Select_Sample[0:len(Front_RNA_Evolution[0])]
            Father_Sample_Elite = [Structure_Sample_RNA_Evolution[elite_num] for elite_num in Crow_Select_Sample]
        else:
            Crow_Select_Evolution = []  # 将拥挤值与个体下标合并排序
            for crow_select_evolution_num in range(len(Front_RNA_Evolution[0])):
                Crow_Select_Evolution_Tem = []
                Crow_Select_Evolution_Tem.append(Front_RNA_Evolution[0][crow_select_evolution_num])
                Crow_Select_Evolution_Tem.append(Crowding_Sample_RNA_Evolution[0][crow_select_evolution_num])
                Crow_Select_Evolution.append(Crow_Select_Evolution_Tem)
            Crow_Select_Evolution = sorted(Crow_Select_Evolution, key=lambda x: x[1], reverse=True)
            Crow_Select_Sample = [x[0] for x in Crow_Select_Evolution]
            Crow_Select_Sample = Crow_Select_Sample[0:100]
            Father_Sample_Elite = [Structure_Sample_RNA_Evolution[elite_num] for elite_num in Crow_Select_Sample]

        # Father_Profile_Fitness_Elite = [Structure_Sample_Profile_Fitness_RNA_Evolution[elite_num] for elite_num in Front_RNA_Evolution[0]]
        # Father_Energy_Fitness_Elite = [Structure_Sample_Energy_Fitness_RNA_Evolution[elite_num] for elite_num in Front_RNA_Evolution[0]]
        Father_Profile_Fitness_Elite, Father_Energy_Fitness_Elite = Fitness_Value(Father_Sample_Elite,Stem_Clean_RNA_Evolution,Sequence_Str_RNA_Evolution,Predict_Label_RNA_Evolution)
        if (Generation_Number == Generation_Num - 1):
            Result_Evolution = Father_Sample_Elite
        Structure_Sample_RNA_Evolution = Father_Sample_Elite + Sample_Next_Generation[len(Father_Sample_Elite):]  # 父代子代合并
        Structure_Sample_Profile_Fitness_RNA_Evolution = Father_Profile_Fitness_Elite + Structure_Sample_Profile_Fitness_Next[len(Father_Sample_Elite):]
        Structure_Sample_Energy_Fitness_RNA_Evolution = Father_Energy_Fitness_Elite + Structure_Sample_Energy_Fitness_Next[len(Father_Sample_Elite):]
        # print(Structure_Sample_RNA_Evolution[0])
        # print(Sample_Next_Generation[0])
        # Front_RNA_Merge, Rank_RNA_Merge = Pareto_Function(Structure_Sample_Profile_Fitness_RNA_Merge, Structure_Sample_Energy_Fitness_RNA_Merge)
        # Crowding_Sample_RNA_Merge = []  # 存储每一层帕累托解的拥挤值
        # for Merge_Num in range(len(Front_RNA_Merge)):  # 获得拥挤值
        #    Distance_Merge = crowding_distance(Structure_Sample_Profile_Fitness_RNA_Merge,Structure_Sample_Energy_Fitness_RNA_Merge,Front_RNA_Merge[Merge_Num])
        #    Crowding_Sample_RNA_Merge.append(Distance_Merge)
        # Structure_Sample_RNA_Evolution, Structure_Sample_Profile_Fitness_RNA_Evolution, Structure_Sample_Energy_Fitness_RNA_Evolution = Evolution_Sample_Select(Front_RNA_Merge, Crowding_Sample_RNA_Merge, Structure_Sample_RNA_Merge, Structure_Sample_Profile_Fitness_RNA_Merge, Structure_Sample_Energy_Fitness_RNA_Merge)
        # Structure_Sample_RNA_Evolution = Structure_Sample_RNA_Merge[0:1000]
        # Structure_Sample_Profile_Fitness_RNA_Evolution = Structure_Sample_Profile_Fitness_RNA_Merge[0:1000]
        # Structure_Sample_Energy_Fitness_RNA_Evolution = Structure_Sample_Energy_Fitness_RNA_Merge[0:1000]

        Generation_Number += 1
        if (Number_Generation_Unchange >= 500):
            Result_Evolution = Father_Sample_Elite
            break
    return Result_Evolution  # Father_Sample_Elite#Structure_Sample_RNA_Evolution, Structure_Sample_Profile_Fitness_RNA_Evolution, Structure_Sample_Energy_Fitness_RNA_Evolution

def Predict_Structure_Trans(RNA_Sequence, Predict_Structure):  # 将预测茎区结果转化为结构，以便于测试其性能
    List_Structure_Number = [-1] * len(RNA_Sequence)
    for stem_number_per in range(len(Predict_Structure)):
        Stem_Start_Performence = Predict_Structure[stem_number_per][0]
        Stem_End_Performence = Predict_Structure[stem_number_per][1]
        Stem_Length = Predict_Structure[stem_number_per][2]
        Index_Per = 0
        while (Index_Per < Stem_Length):
            List_Structure_Number[Stem_Start_Performence + Index_Per] = Stem_End_Performence - Index_Per
            List_Structure_Number[Stem_End_Performence - Index_Per] = Stem_Start_Performence + Index_Per
            Index_Per += 1
    return List_Structure_Number

def Performance_Index(TP, TN, FP, FN):  # 性能指标
    if (TP + FP == 0):
        PPV = 0
    else:
        PPV = TP / (TP + FP)
    if (TP + FN == 0):
        SEN = 0
    else:
        SEN = TP / (TP + FN)
    if (SEN + PPV == 0):
        F_score = 0
    else:
        F_score = (2 * SEN * PPV) / (SEN + PPV)

    return PPV, SEN, F_score

def Sample_Stem_Extend(Stem_NoRe_Extend, Sequence_Extend):
    # Stem_NoRe_Extend = sorted(Stem_NoRe_Extend, key=lambda x: x[2], reverse=True)
    Stem_Extend_Mark = [1] * len(Sequence_Extend)  # 对配对碱基在列表中进行标记
    # print(Stem_NoRe_Extend)
    for num_extend in range(len(Stem_NoRe_Extend)):  # 将配对碱基进行标记
        Front_Start_Extend = Stem_NoRe_Extend[num_extend][0]
        Front_End_Extend = Stem_NoRe_Extend[num_extend][0] + Stem_NoRe_Extend[num_extend][2] - 1
        Rear_Start_Extend = Stem_NoRe_Extend[num_extend][1] - Stem_NoRe_Extend[num_extend][2] + 1
        Rear_End_Extend = Stem_NoRe_Extend[num_extend][1]
        while (Front_Start_Extend <= Front_End_Extend):
            Stem_Extend_Mark[Front_Start_Extend] = 0
            Front_Start_Extend += 1
        while (Rear_Start_Extend <= Rear_End_Extend):
            Stem_Extend_Mark[Rear_Start_Extend] = 2
            Rear_Start_Extend += 1
    for num_extend1 in range(len(Stem_NoRe_Extend)):
        Front_Start_Extend1 = Stem_NoRe_Extend[num_extend1][0]
        Front_End_Extend1 = Stem_NoRe_Extend[num_extend1][0] + Stem_NoRe_Extend[num_extend1][2] - 1
        Rear_Start_Extend1 = Stem_NoRe_Extend[num_extend1][1] - Stem_NoRe_Extend[num_extend1][2] + 1
        Rear_End_Extend1 = Stem_NoRe_Extend[num_extend1][1]
        while (Front_Start_Extend1 > 0 and Rear_End_Extend1 < len(Sequence_Extend) - 1):  # 外部扩展
            if (Stem_Extend_Mark[Front_Start_Extend1 - 1] != 1 or Stem_Extend_Mark[Rear_End_Extend1 + 1] != 1):
                break
            else:
                if ((Sequence_Extend[Front_Start_Extend1 - 1] == 'A' and Sequence_Extend[
                        Rear_End_Extend1 + 1] == 'U') or
                        (Sequence_Extend[Front_Start_Extend1 - 1] == 'U' and Sequence_Extend[
                                Rear_End_Extend1 + 1] == 'A') or
                        (Sequence_Extend[Front_Start_Extend1 - 1] == 'G' and Sequence_Extend[
                                Rear_End_Extend1 + 1] == 'C') or
                        (Sequence_Extend[Front_Start_Extend1 - 1] == 'C' and Sequence_Extend[
                                Rear_End_Extend1 + 1] == 'G')):
                    Front_Start_Extend1 -= 1
                    Rear_End_Extend1 += 1
                    Stem_Extend_Mark[Front_Start_Extend1] = 0
                    Stem_Extend_Mark[Rear_End_Extend1] = 2
                else:
                    break
        while (Rear_Start_Extend1 - Front_End_Extend1 >= 6):
            if (Stem_Extend_Mark[Front_End_Extend1 + 1] != 1 or Stem_Extend_Mark[Rear_Start_Extend1 - 1] != 1):
                break
            else:
                if ((Sequence_Extend[Front_End_Extend1 + 1] == 'A' and Sequence_Extend[
                        Rear_Start_Extend1 - 1] == 'U') or
                        (Sequence_Extend[Front_End_Extend1 + 1] == 'U' and Sequence_Extend[
                                Rear_Start_Extend1 - 1] == 'A') or
                        (Sequence_Extend[Front_End_Extend1 + 1] == 'G' and Sequence_Extend[
                                Rear_Start_Extend1 - 1] == 'C') or
                        (Sequence_Extend[Front_End_Extend1 + 1] == 'C' and Sequence_Extend[
                                Rear_Start_Extend1 - 1] == 'G')):
                    Front_End_Extend1 += 1
                    Rear_Start_Extend1 -= 1
                    Stem_Extend_Mark[Front_End_Extend1] = 0
                    Stem_Extend_Mark[Rear_Start_Extend1] = 2
                else:
                    break
        Stem_NoRe_Extend[num_extend1][0] = Front_Start_Extend1
        Stem_NoRe_Extend[num_extend1][1] = Rear_End_Extend1
        Stem_NoRe_Extend[num_extend1][2] = Rear_End_Extend1 - Rear_Start_Extend1 + 1
    return Stem_NoRe_Extend

Lines_Num = 0
Sequence_Name = ''
Sequence = []
Sequence_Str = ''
Real_Lable = []
Predict_Label = []
p = 0
p_number = 0
All_PPV = 0
All_Sen = 0
All_F = 0
All_Base = 0
True_Base = 0
Predict_Structure_Text = open("Merge_Data_RePeat/Predict_Structure/16SRNA_Predict.txt", 'w')  # 记录预测结果
List_Predict_Value = []
for line in open(Path):
    line_Data = line[0:-1]
    if (Lines_Num % 4 == 0):
        Sequence_Name = line_Data[1:]
    elif (Lines_Num % 4 == 1):
        Sequence = []
        Sequence_Str = line_Data
        for j in range(len(line_Data)):
            Sequence.append(line_Data[j])
    elif (Lines_Num % 4 == 2):
        Real_Lable = []
        for j in range(len(line_Data)):
            Real_Lable.append(line_Data[j])
    else:
        Predict_Label = []
        p_number += 1
        print(p_number)
        print(Sequence_Name)
        for j in range(len(line_Data)):
            Predict_Label.append(line_Data[j])

        Stem_All = Stem_Pool_New(Sequence, Predict_Label)
        Stem_Clean = Stem_All
        # print(len(Stem_All))
        # print(Stem_All)

        # break
        # Stem_Clean = Stem_Profile_Rate_Bracket(Stem_All, Predict_Label)

        # Stem_Clean_Number_Coding_RNA_Evolution = list(range(0, len(Stem_Clean)))  # 获得茎区实数编码
        # Generation_Number = 1

        # Structure_Sample_RNA_Evolution = Create_Sample(Stem_Clean_Number_Coding_RNA_Evolution,len(Sequence_Str))  # 实数编码个体

        # Structure_Sample_Profile_Fitness_RNA_Evolution, Structure_Sample_Energy_Fitness_RNA_Evolution = Fitness_Value(Structure_Sample_RNA_Evolution, Stem_Clean, Sequence_Str, Predict_Label)

        # Structure_Sample_Profile_Fitness_RNA_Evolution = sorted(Structure_Sample_Profile_Fitness_RNA_Evolution, reverse=True)

        # print(len(Structure_Sample_RNA_Evolution))
        # for ii in range(len(Structure_Sample_Profile_Fitness_RNA_Evolution)):
        #    print(Structure_Sample_Profile_Fitness_RNA_Evolution[ii])
        # print(Structure_Sample_RNA_Evolution[ii])

        # Structure


        # print("$$#@$%$#")
        # print(len(Stem_All))
        # print(Stem_All[0])
        # print(len(Stem_Clean))
        # print(len(Stem_Elite))
        # print(Sequence)
        # print(len(Stem_All))
        # Stem_Clean,Stem_Elite= Stem_Profile_Rate(Stem_All, Predict_Label) # 清洗之后的茎区
        # print("#####")
        # print(Stem_Elite)

        # print(len(Stem_Clean))
        # Structure_Sample_RNA, Structure_Sample_Profile_Fitness_RNA, Structure_Sample_Energy_Fitness_RNA = RNA_Secondary_Structure_Evolution(Stem_Clean, Sequence_Str, Predict_Label)
        Evolution_Result = RNA_Secondary_Structure_Evolution(Stem_Clean, Sequence_Str, Predict_Label)
        # RNA_Secondary_Structure_Evolution(Stem_Clean, Sequence_Str, Predict_Label)
        # for iqq in range(len(Evolution_Result)):
        #    print(Evolution_Result[iqq])
        '''Front_RNA, Rank_RNA = Pareto_Function(Structure_Sample_Profile_Fitness_RNA, Structure_Sample_Energy_Fitness_RNA)

        Crowding_Sample_RNA_Evolution1 = []  # 存储每一层帕累托解的拥挤值
        for Evolution_Num in range(len(Front_RNA)):  # 获得拥挤值
            Distance1 = crowding_distance(Structure_Sample_Profile_Fitness_RNA,
                                         Structure_Sample_Energy_Fitness_RNA,
                                         Front_RNA[Evolution_Num])
            Crowding_Sample_RNA_Evolution1.append(Distance1)

        Crow_Select_Evolution1 = []  # 将拥挤值与个体下标合并排序
        for crow_select_evolution_num1 in range(len(Front_RNA[0])):
            Crow_Select_Evolution_Tem1 = []
            Crow_Select_Evolution_Tem1.append(Front_RNA[0][crow_select_evolution_num1])
            Crow_Select_Evolution_Tem1.append(Crowding_Sample_RNA_Evolution1[0][crow_select_evolution_num1])
            Crow_Select_Evolution1.append(Crow_Select_Evolution_Tem1)
        Crow_Select_Evolution1 = sorted(Crow_Select_Evolution1, key=lambda x: x[1], reverse=True)
        Crow_Select_Sample1= [x[0] for x in Crow_Select_Evolution1]
        Crow_Select_Sample1 = Crow_Select_Sample1[0:10]
        Father_Sample_Elite1 = [Structure_Sample_RNA[elite_num1] for elite_num1 in Crow_Select_Sample1]

        #print(Stem_Clean)
        #print(len(Stem_Clean))
        '''
        PPV_Max = 0
        Sen_Max = 0
        F_score_Max = 0
        Optimial_Sample_Structure = []  #
        print(len(Evolution_Result))
        if (len(Evolution_Result) >= 10):
            num_sample = 10
        else:
            num_sample = len(Evolution_Result)
        for ijj in range(num_sample):
            # print(Structure_Sample_Profile_Fitness_RNA[Front_RNA[0][ijj]])
            # print(Structure_Sample_Energy_Fitness_RNA[Front_RNA[0][ijj]])
            # Performer_Sample = Father_Sample_Elite1[ijj]#Structure_Sample_RNA[Father_Sample_Elite1[ijj]]
            Performer_Sample_Stem = [Stem_Clean[xf] for xf in Evolution_Result[ijj]]
            Performer_Sample_Stem_NoRe = Sample_Select_Stem(Performer_Sample_Stem)
            Performer_Sample_Stem_NoRe = Sample_Stem_Extend(Performer_Sample_Stem_NoRe, Sequence)
            List_Structure_Number = Predict_Structure_Trans(Sequence_Str, Performer_Sample_Stem_NoRe)
            Real_Structur, _, _ = Real_Structure_Parallel_Two.Structure_Readting_Real(Sequence_Name)
            TP, TN, FP, FN = Real_Structure_Parallel_Two.Performance(List_Structure_Number, Real_Structur)
            PPV, SEN, F_score = Performance_Index(TP, TN, FP, FN)
            # print("&&")
            # print(PPV)
            # print(SEN)
            # print(F_score)
            if (F_score_Max < F_score):
                Optimial_Sample_Structure = List_Structure_Number
                PPV_Max = PPV
                Sen_Max = SEN
                F_score_Max = F_score
        Predict_Structure_Text.write(">")
        Predict_Structure_Text.write(Sequence_Name)
        Predict_Structure_Text.write("\n")

        for seq_index in range(len(Sequence)):
            Predict_Structure_Text.write(Sequence[seq_index])
            if (seq_index != len(Sequence) - 1):
                Predict_Structure_Text.write(" ")
        Predict_Structure_Text.write("\n")
        for str_index in range(len(Optimial_Sample_Structure)):
            Predict_Structure_Text.write(str(Optimial_Sample_Structure[str_index]))
            if (str_index != len(Optimial_Sample_Structure) - 1):
                Predict_Structure_Text.write(" ")
        Predict_Structure_Text.write("\n")
        List_Value_Tem = []
        List_Value_Tem.append(Sequence_Name)
        List_Value_Tem.append(PPV_Max)
        List_Value_Tem.append(Sen_Max)
        List_Value_Tem.append(F_score_Max)
        List_Predict_Value.append(List_Value_Tem)
        name = ['RNA_Name', 'PPV', 'SEN', 'F_score']
        test = pd.DataFrame(columns=name, data=List_Predict_Value)
        test.to_csv('Merge_Data_RePeat/Predict_Value/16SRNA_Self.csv', encoding='gbk')
        print("%%%%")
        print(PPV_Max)
        print(Sen_Max)
        print(F_score_Max)
        All_PPV += PPV_Max
        All_Sen += Sen_Max
        All_F += F_score_Max

        # Stem_Clean_Sort_Energy = Stem_Sort(Stem_Clean, Sequence)
        # Stem_Clean_Sort = [x[0] for x in Stem_Clean_Sort_Energy] # 取List某一列数据
        # print(Stem_Clean_Sort_Energy)
        # break
        # Stem_Process_List = sorted(Stem_Process_List, key=lambda x: x[1])
        # Stem_Clean_Number_Coding = list(range(0, len(Stem_Clean))) #茎区实数编码
        # print(Stem_Process_List)
        # print(len(Stem_Process_List))
        # print(Stem_Clean_Number_Coding)
        # Structure_Sample = Create_Sample(Stem_Clean_Number_Coding, len(Sequence)) #实数编码个体
        # AAABBB = copy.deepcopy(Structure_Sample)
        # Structure_Sample_Profile_Fitness = Profile_Fitness_Value(Structure_Sample, Predict_Label, Stem_Clean) # 结构的Profile Fitness
        # Structure_Sample_Profile_Fitness,存放父代原始下标的Profile的Fitness值
        # Structure_Sample_Energy_Fitness = Energy_Fitness_Value(Structure_Sample, Stem_Clean, Sequence_Str) # 结构的能量 Fitness
        # print("#####")
        # print(len(Structure_Sample_Profile_Fitness))
        # print(len(Structure_Sample_Energy_Fitness))
        # Structure_Sample_Profile_Fitness, Structure_Sample_Energy_Fitness = Fitness_Value(Structure_Sample, Stem_Clean, Sequence_Str, Predict_Label)

        # Front, Rank = Pareto_Function(Structure_Sample_Profile_Fitness, Structure_Sample_Energy_Fitness)

        # Crowding_Sample = [] # 存储每一层帕累托解的拥挤值

        # for ill in range(len(Front)): # 获得拥挤值
        #    Distance = crowding_distance(Structure_Sample_Profile_Fitness, Structure_Sample_Energy_Fitness,Front[ill])
        #    Crowding_Sample.append(Distance)
        # print("@@@@####$$$$$$$")
        # print(len(Front))
        # print(len(Crowding_Sample))

        # AAA = Championship_Sample_Function(Structure_Sample, 1000, 4)

        # Championship_Number_Index_Sort = Championship_Sort(AAA, Front, Rank, Crowding_Sample)

        # Sample_Next_Generation = GA_Sample_Evlution(Structure_Sample, Championship_Number_Index_Sort)

        # Structure_Sample_Profile_Fitness_Next, Structure_Sample_Energy_Fitness_Next = Fitness_Value(Sample_Next_Generation, Stem_Clean, Sequence_Str, Predict_Label)


        # print(Sample_Next_Generation[0])
        # print(Structure_Sample_Profile_Fitness_Next[0])
        # print(Structure_Sample_Energy_Fitness_Next[0])

        # Structure_Sample = Structure_Sample + Sample_Next_Generation
        # Structure_Sample_Profile_Fitness = Structure_Sample_Profile_Fitness + Structure_Sample_Profile_Fitness_Next
        # Structure_Sample_Energy_Fitness = Structure_Sample_Energy_Fitness + Structure_Sample_Energy_Fitness_Next

        # print(len(Structure_Sample))
        # print(len(Structure_Sample_Profile_Fitness))
        # print(len(Structure_Sample_Energy_Fitness))

        # print(Structure_Sample[1000])
        # print(Structure_Sample_Profile_Fitness[1000])
        # print(Structure_Sample_Energy_Fitness[1000])

        '''print("################UUUUUUUUU#####################")
        print(len(Sample_Next_Generation))
        for iikk in range(len(Sample_Next_Generation)):
            print(Sample_Next_Generation[iikk])
        '''
        '''print(len(AAA))
        print("$$$$$$$$$$")
        for iyy in range(len(AAA)):
            print(AAA[iyy])'''
        '''for iyu in range(len(Structure_Sample)):
            for opi in range(len(Structure_Sample[iyu])):
                if(Structure_Sample[iyu][opi] != AAABBB[iyu][opi]):
                    print(77766545)'''
        # for i in range(len(Structure_Sample_Profile_Fitness)):
        #    print(Structure_Sample_Profile_Fitness[i])
        #    print(Structure_Sample_Energy_Fitness[i])
        # Structure_Sample_Fitness = []
        # 计算Profile适应度值
        # for iv in range(len(Structure_Sample)):
        # Tem_Fitness = []
        # Profile_Rate_Sample = Profile_Rate(Predict_Label, Structure_Sample[iv], Stem_Clean)
        # Tem_Fitness.append(Structure_Sample[iv])
        # Tem_Fitness.append(Profile_Rate_Sample)
        # Structure_Sample_Fitness.append(Tem_Fitness)
        # Fitness_All_Sample = [x[1] for x in Structure_Sample_Fitness]  # 取出所有的适应度值
        # Fitness_Mean = np.mean(Fitness_All_Sample) # 计算适应度平均值
        # Fitness_Max = np.max(Fitness_All_Sample) # 计算机适应度最大值
        # Fitness_Min = np.min(Fitness_All_Sample) # 计算适应度最小值
        # Fitness_Var = np.var(Fitness_All_Sample)
        # Fitness_Std = np.std(Fitness_All_Sample)
        # Structure_Sample_Fitness = sorted(Structure_Sample_Fitness, key=lambda x: x[1], reverse=True) #按照适应度逆序排序

        # for ipp in range(1000):
        # print(Fitness_Var)
        # print(Fitness_Std)
        # print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
        # print(ipp)
        # print(Fitness_Max)
        # print(Fitness_Min)
        # print(Fitness_Mean)
        # Structure_Sample_Fitness = Sample_Evolution(Structure_Sample_Fitness, Fitness_Max, Fitness_Mean, Predict_Label, Stem_Clean, ipp)
        # Fitness_All_Sample = [x[1] for x in Structure_Sample_Fitness]  # 取出所有的适应度值
        # Fitness_Mean = np.mean(Fitness_All_Sample)  # 计算适应度平均值
        # Fitness_Max = np.max(Fitness_All_Sample)  # 计算机适应度最大值
        # Fitness_Min = np.min(Fitness_All_Sample)  # 计算适应度最小值
        # Fitness_Var = np.var(Fitness_All_Sample)
        # Fitness_Std = np.std(Fitness_All_Sample)

        '''Championship_Sample_List = Championship_Sample_Function(Structure_Sample_Fitness, 1000, 4)
        print(len(Championship_Sample_List))
        print(Championship_Sample_List[0])
        AA = copy.deepcopy(Championship_Sample_List[0:10])
        AA[0][0][1] = 100
        print(AA[0][0][1])
        print(Championship_Sample_List[0][0][1])
        print(type(AA))'''
        # for iii in range(10000):
        #    print(Structure_Sample_Fitness[iii][1])
        # Fitness_All_Sample = [x[1] for x in Structure_Sample_Fitness] #取出所有的适应度值
        # Fitness_Mean = np.mean(Fitness_All_Sample) # 计算适应度平均值
        # Fitness_Max = np.max(Fitness_All_Sample) # 计算机适应度最大值
        # Fitness_Min = np.min(Fitness_All_Sample) # 计算适应度最小值



        # All_Sample_Stem_Optimization = [] #保存自身优化后的个体
        # Predicted_Result = []
        # for i in range(len(Structure_Sample)):
        # print(Structure_Sample[i])
        # Profile_Rate_Number, Total_Rate = Profile_Rate(Predict_Label, Structure_Sample[i])
        # Sample_Stem_Optimization = []
        # if(len(Structure_Sample[i]) <= 1):
        # Sample_Stem_Optimization.append(Structure_Sample[i])
        # Sample_Stem_Optimization.append(1)
        # else:
        # Sample_Stem_Optimization = Sample_Optimization(Structure_Sample[i], Predict_Label)
        # print(Sample_Stem_Optimization)
        # All_Sample_Stem_Optimization.append(Sample_Stem_Optimization)
        # print(Sample_Stem_Optimization[1])
        # print(Sample_Stem_Optimization)
        # print(Sample_Stem_Optimization)
        # Sample_Stem_Selected = Sample_Select_Stem(Sample_Stem_Optimization[0])
        # print(Sample_Stem_Selected)
        # Commond_Sample = HFold_Command_Create(Sequence_Str, Sample_Stem_Selected)
        # os.chdir('/media/disk/lyuwang/RNA_Secondary_Structure_Program/HFold-master')
        # text = os.popen(Commond_Sample).read()
        # list_str = text.split()
        # print(Commond_Sample)
        # if(len(list_str) != 0):
        # print(list_str[3])
        # Predicted_Result_Tem.append(list_str[3])
        # Predicted_Result_Tem.append(float(list_str[-1]))
        # Predicted_Result.append(Predicted_Result_Tem)
        # break
        # break
        # All_Sample_Stem_Optimization = sorted(All_Sample_Stem_Optimization, reverse=True, key=lambda x: x[1])
        # print(All_Sample_Stem_Optimization)
        # break
        '''Predict_Result = []
        for i_op in range(11):
            os.chdir("/media/disk/lyuwang/RNA_Secondary_Structure_GA_2021.06.12")
            if(i_op != 10):
                Sample_NoRe_Profile = Sample_Select_Stem(All_Sample_Stem_Optimization[i_op][0])
            else:
                Sample_NoRe_Profile = []
            Commond_HFold = HFold_Command_Create(Sequence_Str, Sample_NoRe_Profile)
            os.chdir('/media/disk/lyuwang/RNA_Secondary_Structure_Program/HFold-master')
            text = os.popen(Commond_HFold).read()
            list_str = text.split()
            Predict_Result.append(list_str[3])
        for iii in range(len(Predict_Result)):
            os.chdir("/media/disk/lyuwang/RNA_Secondary_Structure_GA_2021.06.12")
            Predict_Structure_Tran = Real_Structure.Predict_Structur_Transfor(Predict_Result[iii])
            print(Predict_Structure_Tran)
            Real_Structur, Real_Sequence, Real_Restriction = Real_Structure.Structure_Readting_Real(Sequence_Name)
            TP, TN, FP, FN = Real_Structure.Performance(Predict_Structure_Tran, Real_Structur)
            if (TP + FP == 0):
                PPV = 0
            else:
                PPV = TP / (TP + FP)
            if (TP + FN == 0):
                SEN = 0
            else:
                SEN = TP / (TP + FN)
            if (SEN + PPV == 0):
                F_score = 0
            else:
                F_score = (2 * SEN * PPV) / (SEN + PPV)
            All_Sen += SEN
            All_PPV += PPV
            All_F += F_score
            print("@@@@@@@@@@@@@@@@@@@@@@@@")
            print(PPV)
            print(SEN)
            print(F_score)
        '''
        # print(Stem_Process_List)
        # print(len(Stem_Process_List))
        # Sample_Stem_Selected = Sample_Select_Stem(Stem_All)
        # print(Sample_Stem_Selected)
        '''Predicted_Result_Sort = sorted(Predicted_Result, key=lambda x: x[1])
        os.chdir("/media/disk/lyuwang/RNA_Secondary_Structure_GA_2021.06.12")

        Predict_Structure_Tran = Real_Structure.Predict_Structur_Transfor(Predicted_Result_Sort[0][0])
        Real_Structur, Real_Sequence, Real_Restriction = Real_Structure.Structure_Readting_Real(Sequence_Name)
        TP, TN, FP, FN = Real_Structure.Performance(Predict_Structure_Tran, Real_Structur)
        if (TP + FP == 0):
            PPV = 0
        else:
            PPV = TP / (TP + FP)
        if (TP + FN == 0):
            SEN = 0
        else:
            SEN = TP / (TP + FN)
        if (SEN + PPV == 0):
            F_score = 0
        else:
            F_score = (2 * SEN * PPV) / (SEN + PPV)
        All_Sen += SEN
        All_PPV += PPV
        All_F += F_score
        print("@@@@@@@@@@@@@@@@@@@@@@@@")
        print(PPV)
        print(SEN)
        print(F_score)
        '''
        # break
    Lines_Num += 1

# print("$$$$$$$$$$$$$$$$")
# print(All_Base)
# print(True_Base)
# print(True_Base/All_Base)
print("#######################")
print(All_PPV / p_number)
print(All_Sen / p_number)
print(All_F / p_number)
